'use strict';
const path = require('node:path');

const ROOT = path.resolve(__dirname, '..');

/** Reads settings from environment variables (and the optional .env file). `overrides` is used by the tests. */
function loadConfig(overrides = {}) {
  try { process.loadEnvFile(path.join(ROOT, '.env')); } catch { /* no .env file - defaults are fine */ }
  const e = process.env;
  const bool = (v, d) => (v === undefined || v === '' ? d : /^(1|true|yes|on)$/i.test(v));
  const num = (v, d) => (v === undefined || v === '' || !Number.isFinite(+v) ? d : +v);

  const production = e.NODE_ENV === 'production';
  const smtp = { host: e.SMTP_HOST || '', port: num(e.SMTP_PORT, 587), user: e.SMTP_USER || '', pass: e.SMTP_PASS || '', from: e.SMTP_FROM || '' };

  return {
    root: ROOT,
    production,
    port: num(e.PORT, 3000),
    host: e.HOST || '127.0.0.1',
    dbFile: e.DB_FILE === ':memory:' ? ':memory:' : path.resolve(ROOT, e.DB_FILE || 'data/campus.db'),
    publicDir: path.resolve(ROOT, e.PUBLIC_DIR || 'public'),
    appSecret: e.APP_SECRET || '',
    sessionDays: num(e.SESSION_DAYS, 14),
    cookieSecure: bool(e.COOKIE_SECURE, production),
    corsOrigins: (e.CORS_ORIGINS || '').split(',').map(x => x.trim()).filter(Boolean),
    trustProxy: bool(e.TRUST_PROXY, false),
    requireCollegeEmail: bool(e.REQUIRE_COLLEGE_EMAIL, false),
    seedDemo: bool(e.SEED_DEMO_DATA, true),
    demoAutoReply: bool(e.DEMO_AUTOREPLY, true),
    demoReplyDelayMs: num(e.DEMO_REPLY_DELAY_MS, 1200),
    showOtp: bool(e.DEV_SHOW_OTP, !production && !smtp.host),
    logRequests: bool(e.LOG_REQUESTS, !production),
    otp: { ttlMs: 5 * 60e3, maxTries: 5, resendWaitMs: 30e3 },
    smtp,
    razorpay: { keyId: e.RAZORPAY_KEY_ID || '', keySecret: e.RAZORPAY_KEY_SECRET || '', apiBase: e.RAZORPAY_API_BASE || 'https://api.razorpay.com/v1' },
    ...overrides,
  };
}

module.exports = { loadConfig };
