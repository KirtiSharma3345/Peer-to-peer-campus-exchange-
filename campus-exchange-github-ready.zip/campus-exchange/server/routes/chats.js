'use strict';
const { HttpError } = require('../lib/http');
const { str } = require('../lib/validate');
const { newId } = require('../lib/security');
const { CHAT_SQL, chatDto, messageDto } = require('../lib/models');

const DEMO_REPLIES = ['Hi! Yes, it is still available.', 'Sure, we can meet at the campus location mentioned.', 'The price is slightly negotiable. What is your offer?', 'Okay, deal! Message me when you reach.'];

module.exports = function chatRoutes(r, app) {
  const { db, config } = app;

  /* a chat is visible only to its buyer and seller */
  const mine = ctx => {
    const c = db.get(`${CHAT_SQL} WHERE c.id = ?`, ctx.params.id);
    if (!c || (c.buyer_id !== ctx.user.id && c.seller_id !== ctx.user.id)) throw new HttpError(404, 'Conversation not found.');
    return c;
  };
  const messagesOf = (chatId, after = 0) => db.all('SELECT * FROM messages WHERE chat_id = ? AND id > ? ORDER BY id', chatId, after).map(messageDto);

  r.get('/api/chats', ctx => db.all(`${CHAT_SQL} WHERE c.buyer_id = ? OR c.seller_id = ? ORDER BY COALESCE(last_at, c.created_at) DESC`, ctx.user.id, ctx.user.id).map(chatDto), { auth: true });

  /* open (or create) the conversation between the logged-in buyer and a listing's seller */
  r.post('/api/chats', ctx => {
    const u = ctx.user, listingId = str(ctx.body.listingId, 'Listing');
    const l = db.get('SELECT id, title, seller_id FROM listings WHERE id = ?', listingId);
    if (!l) throw new HttpError(404, 'Item not found.');
    if (l.seller_id === u.id) throw new HttpError(400, 'This is your own listing.');
    let c = db.get('SELECT id FROM chats WHERE listing_id = ? AND buyer_id = ?', l.id, u.id);
    if (!c) {
      c = { id: newId('c') };
      db.run('INSERT INTO chats (id, listing_id, title, buyer_id, seller_id, created_at) VALUES (?,?,?,?,?,?)', c.id, l.id, l.title, u.id, l.seller_id, Date.now());
      ctx.status = 201;
    }
    return chatDto(db.get(`${CHAT_SQL} WHERE c.id = ?`, c.id));
  }, { auth: true });

  r.get('/api/chats/:id', ctx => { const c = mine(ctx); return { chat: chatDto(c), messages: messagesOf(c.id) }; }, { auth: true });

  /* polling: only the messages newer than ?after=<message id> */
  r.get('/api/chats/:id/messages', ctx => { const c = mine(ctx); return { messages: messagesOf(c.id, +ctx.query.after || 0) }; }, { auth: true });

  r.post('/api/chats/:id/messages', ctx => {
    const c = mine(ctx), text = str(ctx.body.text, 'Message', { max: 1000 });
    const res = db.run('INSERT INTO messages (chat_id, sender_id, text, created_at) VALUES (?,?,?,?)', c.id, ctx.user.id, text, Date.now());
    const msg = messageDto(db.get('SELECT * FROM messages WHERE id = ?', res.lastInsertRowid));

    // Demo sellers are not real people, so they answer automatically (lets you show the chat with a single account).
    if (config.demoAutoReply && c.seller_demo && ctx.user.id === c.buyer_id) {
      setTimeout(() => {
        try {
          const n = db.get('SELECT COUNT(*) AS n FROM messages WHERE chat_id = ?', c.id).n;
          db.run('INSERT INTO messages (chat_id, sender_id, text, created_at) VALUES (?,?,?,?)', c.id, c.seller_id, DEMO_REPLIES[Math.floor(n / 2) % DEMO_REPLIES.length], Date.now());
        } catch { /* database closed or chat removed - nothing to do */ }
      }, config.demoReplyDelayMs).unref();
    }
    ctx.status = 201;
    return msg;
  }, { auth: true });
};
