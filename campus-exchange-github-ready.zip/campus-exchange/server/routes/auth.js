'use strict';
const crypto = require('node:crypto');
const { HttpError, bad } = require('../lib/http');
const { str, int, emailOf, password } = require('../lib/validate');
const { hashPassword, verifyPassword, sha256, hmac, newToken, safeEqual } = require('../lib/security');
const { userDto } = require('../lib/models');

const COLLEGE_EMAIL = /@[\w.-]+\.(ac\.in|edu|edu\.in)$/i;

module.exports = function authRoutes(r, app) {
  const { db, config, limit, mailer, sessions, secret, catalog } = app;
  const branchCodes = Object.keys(catalog.BRANCHES).filter(k => k !== 'ALL');
  let dummyHash; // used so that "unknown e-mail" and "wrong password" take the same time
  const getDummy = async () => (dummyHash ||= await hashPassword('not-a-real-password'));

  const startSession = (ctx, userId) => {
    const token = sessions.create(userId);
    ctx.setCookie(sessions.COOKIE, token, { maxAge: config.sessionDays * 86400, secure: config.cookieSecure });
  };
  const branchOf = v => {
    if (v === undefined || v === null || v === '') return '';
    if (!branchCodes.includes(v)) throw bad('Please choose a valid branch.');
    return v;
  };

  /* ---------- register / login / logout / me ---------- */
  r.post('/api/auth/register', async ctx => {
    limit(`register:${ctx.ip}`, 200, 3600e3); // generous: a whole campus can share one Wi-Fi IP
    const b = ctx.body;
    const name = str(b.name, 'Name', { max: 80 });
    const email = emailOf(b.email);
    if (config.requireCollegeEmail && !COLLEGE_EMAIL.test(email)) throw bad('Please use your college e-mail ID.');
    const pw = password(b.password);
    const hostel = str(b.hostel, 'Hostel', { max: 40, optional: true });
    const branch = branchOf(b.branch), sem = int(b.sem, 'Semester', { min: 0, max: 8, optional: true });
    if (db.get('SELECT 1 FROM users WHERE email = ?', email)) throw new HttpError(409, 'This e-mail is already registered. Please login.');
    const hash = await hashPassword(pw);
    try {
      db.run('INSERT INTO users (name, email, pass_hash, hostel, branch, sem, created_at) VALUES (?,?,?,?,?,?,?)', name, email, hash, hostel, branch, sem, Date.now());
    } catch { throw new HttpError(409, 'This e-mail is already registered. Please login.'); }
    ctx.status = 201;
    return { ok: true };
  });

  r.post('/api/auth/login', async ctx => {
    const email = String(ctx.body.email || '').trim().toLowerCase(), pw = String(ctx.body.password || '');
    limit.check(`login:ip:${ctx.ip}`, 300, 15 * 60e3); // per-IP is loose (shared campus IP); the strict limit is per account below
    limit.check(`login:${email}`, 8, 15 * 60e3);
    const u = db.get('SELECT * FROM users WHERE email = ?', email);
    const ok = await verifyPassword(pw, u ? u.pass_hash : await getDummy());
    if (!u || !ok) {
      limit.hit(`login:ip:${ctx.ip}`); limit.hit(`login:${email}`);
      throw new HttpError(401, 'Invalid e-mail or password.');
    }
    limit.reset(`login:${email}`);
    startSession(ctx, u.id);
    return { user: userDto(u) };
  });

  r.post('/api/auth/logout', ctx => {
    sessions.destroy(ctx.cookies[sessions.COOKIE]);
    ctx.setCookie(sessions.COOKIE, '', { maxAge: 0, secure: config.cookieSecure });
    return { ok: true };
  });

  r.get('/api/auth/me', ctx => ({ user: ctx.user ? userDto(ctx.user) : null }));

  r.patch('/api/users/me', ctx => {
    const b = ctx.body;
    const branch = branchOf(b.branch), sem = int(b.sem, 'Semester', { min: 0, max: 8, optional: true }), hostel = str(b.hostel, 'Hostel', { max: 40, optional: true });
    db.run('UPDATE users SET branch = ?, sem = ?, hostel = ? WHERE id = ?', branch, sem, hostel, ctx.user.id);
    return { user: userDto(db.get('SELECT * FROM users WHERE id = ?', ctx.user.id)) };
  }, { auth: true });

  /* ---------- forgot password: e-mail -> OTP -> new password ---------- */
  const { ttlMs, maxTries, resendWaitMs } = config.otp;

  r.post('/api/auth/forgot', async ctx => {
    const email = emailOf(ctx.body.email);
    limit(`forgot:ip:${ctx.ip}`, 100, 3600e3);
    limit(`forgot:${email}`, 6, 3600e3);
    const u = db.get('SELECT id, email FROM users WHERE email = ? AND is_demo = 0', email);
    if (!u) throw new HttpError(404, 'No account found with this email. Please check it or register.');
    const prev = db.get('SELECT sent_at FROM password_resets WHERE user_id = ?', u.id);
    if (prev && Date.now() - prev.sent_at < resendWaitMs) {
      throw new HttpError(429, `Please wait ${Math.ceil((resendWaitMs - (Date.now() - prev.sent_at)) / 1000)} seconds before requesting another OTP.`);
    }
    const otp = String(crypto.randomInt(100000, 1000000)), now = Date.now();
    db.run(`INSERT INTO password_resets (user_id, code_hash, expires_at, tries, reset_token_hash, sent_at) VALUES (?,?,?,0,NULL,?)
            ON CONFLICT(user_id) DO UPDATE SET code_hash = excluded.code_hash, expires_at = excluded.expires_at, tries = 0, reset_token_hash = NULL, sent_at = excluded.sent_at`,
      u.id, hmac(secret, otp + email), now + ttlMs, now);
    try {
      await mailer.send({ to: email, subject: 'Your Campus Exchange password reset OTP', text: `Your OTP is ${otp}. It is valid for ${ttlMs / 60000} minutes.\nIf you did not ask for this, you can ignore this e-mail.` });
    } catch (err) {
      console.error('[mail] failed:', err.message);
      db.run('DELETE FROM password_resets WHERE user_id = ?', u.id);
      throw new HttpError(502, 'Could not send the OTP e-mail. Please try again later.');
    }
    return { ok: true, expiresInSec: ttlMs / 1000, resendInSec: resendWaitMs / 1000, ...(config.showOtp ? { demoOtp: otp } : {}) };
  });

  r.post('/api/auth/verify-otp', ctx => {
    const email = emailOf(ctx.body.email), otp = String(ctx.body.otp || '').trim();
    limit.check(`otp:ip:${ctx.ip}`, 300, 15 * 60e3); limit.hit(`otp:ip:${ctx.ip}`);
    const u = db.get('SELECT id FROM users WHERE email = ?', email);
    const row = u && db.get('SELECT * FROM password_resets WHERE user_id = ?', u.id);
    if (!row) throw bad('Session expired. Please request a new OTP.');
    if (Date.now() > row.expires_at) throw bad('This OTP has expired. Tap “Resend OTP”.');
    if (row.tries >= maxTries) throw new HttpError(429, 'Too many wrong attempts. Tap “Resend OTP” for a new one.');
    if (!/^\d{6}$/.test(otp) || !safeEqual(hmac(secret, otp + email), row.code_hash)) {
      db.run('UPDATE password_resets SET tries = tries + 1 WHERE user_id = ?', u.id);
      throw bad(`Incorrect OTP. ${Math.max(0, maxTries - row.tries - 1)} attempt(s) left.`);
    }
    const resetToken = newToken();
    db.run('UPDATE password_resets SET reset_token_hash = ?, expires_at = ? WHERE user_id = ?', sha256(resetToken), Date.now() + ttlMs, u.id);
    return { resetToken };
  });

  r.post('/api/auth/reset-password', async ctx => {
    const email = emailOf(ctx.body.email), token = String(ctx.body.resetToken || ''), pw = password(ctx.body.password);
    const u = db.get('SELECT id FROM users WHERE email = ?', email);
    const row = u && db.get('SELECT * FROM password_resets WHERE user_id = ?', u.id);
    if (!row || !row.reset_token_hash || Date.now() > row.expires_at || !safeEqual(sha256(token), row.reset_token_hash)) {
      throw bad('Your reset session expired. Please start again.');
    }
    const hash = await hashPassword(pw);
    db.tx(() => {
      db.run('UPDATE users SET pass_hash = ? WHERE id = ?', hash, u.id);
      db.run('DELETE FROM password_resets WHERE user_id = ?', u.id);
      sessions.destroyAllFor(u.id); // anyone logged in with the old password is signed out
    });
    return { ok: true };
  });
};
