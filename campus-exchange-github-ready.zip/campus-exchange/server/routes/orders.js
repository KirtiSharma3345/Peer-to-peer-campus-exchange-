'use strict';
const crypto = require('node:crypto');
const { HttpError, bad } = require('../lib/http');
const { str, int, oneOf } = require('../lib/validate');
const { newId } = require('../lib/security');
const { ORDER_SQL, orderDto } = require('../lib/models');
const rzp = require('../lib/razorpay');

module.exports = function orderRoutes(r, app) {
  const { db, config } = app;

  /* The server always recomputes the price from the listing - the amount sent by the browser is never trusted. */
  function priceFor(listingId, qtyInput, buyerId) {
    const l = db.get('SELECT * FROM listings WHERE id = ?', listingId);
    if (!l) throw new HttpError(404, 'Item not found.');
    if (l.seller_id === buyerId) throw bad('You cannot pay for your own listing.');
    if (!['SELL', 'RENT'].includes(l.type) || !(l.price > 0)) throw bad('This listing has no payable amount. Use chat to arrange it with the seller.');
    if (l.status === 'SOLD') throw new HttpError(409, 'Sorry, this item has already been sold or rented.');
    const rent = l.type === 'RENT';
    const qty = rent ? int(qtyInput, 'Rental duration', { min: 1, max: 30, optional: true, def: 1 }) : 1;
    const deposit = rent ? l.deposit : 0;
    return { l, rent, qty, deposit, amount: l.price * qty + deposit };
  }

  /* Step 1 of a real Razorpay payment: create the order on Razorpay and remember it. */
  r.post('/api/payments/razorpay/order', async ctx => {
    if (!rzp.enabled(config)) throw bad('Online payments are not enabled on this server.');
    const { l, qty, amount } = priceFor(str(ctx.body.listingId, 'Listing'), ctx.body.qty, ctx.user.id);
    const order = await rzp.createOrder(config, { amountPaise: amount * 100, receipt: 'cx_' + crypto.randomBytes(5).toString('hex'), notes: { listingId: l.id, buyerId: String(ctx.user.id) } });
    db.run('INSERT INTO payments (id, listing_id, user_id, qty, amount, used, created_at) VALUES (?,?,?,?,?,0,?)', order.id, l.id, ctx.user.id, qty, amount, Date.now());
    return { keyId: config.razorpay.keyId, orderId: order.id, amount: amount * 100, currency: 'INR' };
  }, { auth: true });

  /* Place an order. Methods: cod (pay on meetup) | online (verified Razorpay payment) | upi / card / nb (DEMO gateway, no real money) */
  r.post('/api/orders', ctx => {
    const u = ctx.user, b = ctx.body;
    const listingId = str(b.listingId, 'Listing');
    const method = oneOf(b.method, ['upi', 'card', 'nb', 'cod', 'online'], 'Payment method');
    const live = rzp.enabled(config);
    if (method === 'online' && !live) throw bad('Online payments are not enabled on this server.');
    if (live && ['upi', 'card', 'nb'].includes(method)) throw bad('Please use the secure online payment option.');

    const { l, rent, qty, deposit, amount } = priceFor(listingId, b.qty, u.id);
    let label = 'Pay on meetup', status = 'PAY_ON_MEETUP', ref = 'CX' + Date.now().toString(36).toUpperCase() + crypto.randomInt(100, 1000), paymentId = null;

    if (method === 'online') {
      const p = b.razorpay || {};
      if (!rzp.verifySignature(config, p.orderId, p.paymentId, p.signature)) throw bad('Payment verification failed. If money was deducted, contact support with your payment id.');
      label = 'Razorpay'; status = 'PAID'; ref = String(p.paymentId).slice(0, 60); paymentId = String(p.orderId);
    } else if (method !== 'cod') {
      // demo gateway: keep only a short label (e.g. "Visa ···· 1111"), never anything that looks like a card number
      label = str(b.label, 'Payment details', { max: 60, optional: true });
      if (!label || /\d{9,}/.test(label.replace(/[\s-]/g, ''))) label = { upi: 'UPI', card: 'Card', nb: 'Net Banking' }[method];
      status = 'PAID';
    }

    const order = db.tx(() => {
      const cur = db.get('SELECT status FROM listings WHERE id = ?', l.id);
      if (!cur) throw new HttpError(404, 'Item not found.');
      if (cur.status === 'SOLD') throw new HttpError(409, method === 'online' ? `Sorry, this item was just sold. Your payment id is ${ref} – please contact support for a refund.` : 'Sorry, someone else just got this item.');
      if (paymentId) {
        const pay = db.get('SELECT * FROM payments WHERE id = ? AND user_id = ? AND listing_id = ? AND used = 0', paymentId, u.id, l.id);
        if (!pay || pay.amount !== amount || pay.qty !== qty) throw bad('This payment does not match your order.');
        db.run('UPDATE payments SET used = 1 WHERE id = ?', paymentId);
      }
      const id = newId('o');
      db.run(`INSERT INTO orders (id, ref, listing_id, title, type, price, qty, unit, deposit, amount, method, status, buyer_id, seller_id, location, created_at)
              VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, id, ref, l.id, l.title, l.type, l.price, qty, rent ? l.rent_unit : null, deposit, amount, label, status, u.id, l.seller_id, l.location, Date.now());
      db.run("UPDATE listings SET status = 'SOLD' WHERE id = ?", l.id); // reserved / sold
      return db.get(`${ORDER_SQL} WHERE o.id = ?`, id);
    });
    ctx.status = 201;
    return orderDto(order);
  }, { auth: true });

  /* my purchases (role=buy), my sales (role=sell), or both */
  r.get('/api/orders', ctx => {
    const role = ctx.query.role, u = ctx.user.id;
    const where = role === 'buy' ? 'o.buyer_id = ?' : role === 'sell' ? 'o.seller_id = ?' : '(o.buyer_id = ? OR o.seller_id = ?)';
    return db.all(`${ORDER_SQL} WHERE ${where} ORDER BY o.created_at DESC`, ...(role === 'buy' || role === 'sell' ? [u] : [u, u])).map(orderDto);
  }, { auth: true });

  /* seller confirms that cash / UPI was received at the meetup */
  r.post('/api/orders/:id/confirm', ctx => {
    const res = db.run("UPDATE orders SET status = 'PAID' WHERE id = ? AND seller_id = ? AND status = 'PAY_ON_MEETUP'", ctx.params.id, ctx.user.id);
    if (!res.changes) throw new HttpError(404, 'No pending payment found for this order.');
    return orderDto(db.get(`${ORDER_SQL} WHERE o.id = ?`, ctx.params.id));
  }, { auth: true });
};
