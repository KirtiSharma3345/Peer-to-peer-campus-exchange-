'use strict';
const { HttpError, bad } = require('../lib/http');
const { str, int, oneOf } = require('../lib/validate');
const { BOOK_SQL, bookDto } = require('../lib/models');

const slug = s => String(s).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

module.exports = function bookRoutes(r, app) {
  const { db, catalog } = app;

  r.get('/api/books', () => db.all(`${BOOK_SQL} ORDER BY b.sem, b.title`).map(bookDto));

  /* a student adds a textbook that is missing from the catalog */
  r.post('/api/books', ctx => {
    const b = ctx.body;
    const title = str(b.title, 'Title', { max: 120 }), author = str(b.author, 'Author', { max: 120 });
    const publisher = str(b.publisher, 'Publisher', { max: 80, optional: true }), subject = str(b.subject, 'Subject', { max: 80, optional: true }) || 'General';
    const branch = oneOf(b.branch, Object.keys(catalog.BRANCHES), 'Branch'), sem = int(b.sem, 'Semester', { min: 1, max: 8 });
    if (db.get('SELECT 1 FROM books WHERE lower(title) = lower(?) AND lower(author) = lower(?)', title, author)) throw new HttpError(409, 'This book is already in the catalog.');
    let id = slug(title) || 'book';
    if (db.get('SELECT 1 FROM books WHERE id = ?', id)) id += '-' + (slug(author) || Date.now().toString(36));
    if (db.get('SELECT 1 FROM books WHERE id = ?', id)) id += '-' + Date.now().toString(36);
    db.run('INSERT INTO books (id, title, author, publisher, subject, sem, branches, custom, added_by) VALUES (?,?,?,?,?,?,?,1,?)',
      id, title, author, publisher, subject, sem, JSON.stringify([branch]), ctx.user.id);
    ctx.status = 201;
    return bookDto(db.get(`${BOOK_SQL} WHERE b.id = ?`, id));
  }, { auth: true });

  r.delete('/api/books/:id', ctx => {
    const b = db.get('SELECT * FROM books WHERE id = ?', ctx.params.id);
    if (!b || !b.custom || b.added_by !== ctx.user.id) throw new HttpError(403, 'You can remove only books that you added.');
    if (db.get('SELECT 1 FROM listings WHERE book_id = ?', b.id)) throw new HttpError(409, 'Cannot remove: listings are linked to this book.');
    db.run('DELETE FROM books WHERE id = ?', b.id);
    return { ok: true };
  }, { auth: true });
};
