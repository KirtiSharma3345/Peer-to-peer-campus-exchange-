'use strict';
const { HttpError } = require('../lib/http');
const { str, int } = require('../lib/validate');
const { newId } = require('../lib/security');
const { REVIEW_SQL, reviewDto } = require('../lib/models');

module.exports = function reviewRoutes(r, app) {
  const { db } = app;

  /* public: all reviews for one seller */
  r.get('/api/reviews', ctx => {
    const seller = int(ctx.query.seller, 'Seller', { min: 1 });
    return db.all(`${REVIEW_SQL} WHERE r.seller_id = ? ORDER BY r.created_at DESC`, seller).map(reviewDto);
  });

  /* one review per completed (PAID) order, written by the buyer of that order */
  r.post('/api/reviews', ctx => {
    const u = ctx.user, orderId = str(ctx.body.orderId, 'Order');
    const rating = int(ctx.body.rating, 'Rating', { min: 1, max: 5 }), text = str(ctx.body.text, 'Review', { max: 400, optional: true });
    const o = db.get('SELECT * FROM orders WHERE id = ?', orderId);
    if (!o || o.buyer_id !== u.id || o.status !== 'PAID') throw new HttpError(403, 'You can review only after a completed payment.');
    if (db.get('SELECT 1 FROM reviews WHERE order_id = ?', o.id)) throw new HttpError(409, 'You already reviewed this order.');
    const id = newId('r');
    db.run('INSERT INTO reviews (id, order_id, listing_id, title, seller_id, buyer_id, buyer_name, rating, text, is_demo, created_at) VALUES (?,?,?,?,?,?,?,?,?,0,?)',
      id, o.id, o.listing_id, o.title, o.seller_id, u.id, u.name, rating, text, Date.now());
    ctx.status = 201;
    return reviewDto(db.get(`${REVIEW_SQL} WHERE r.id = ?`, id));
  }, { auth: true });

  r.delete('/api/reviews/:id', ctx => {
    const res = db.run('DELETE FROM reviews WHERE id = ? AND buyer_id = ?', ctx.params.id, ctx.user.id);
    if (!res.changes) throw new HttpError(404, 'Review not found.');
    return { ok: true };
  }, { auth: true });
};
