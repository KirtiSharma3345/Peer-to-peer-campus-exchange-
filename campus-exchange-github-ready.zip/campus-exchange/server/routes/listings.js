'use strict';
const { HttpError, bad } = require('../lib/http');
const { str, int, oneOf } = require('../lib/validate');
const { newId } = require('../lib/security');
const { LISTING_SQL, listingDto, recommend } = require('../lib/models');

const CATEGORIES = ['Books', 'Electronics', 'Lab Gear', 'Furniture', 'Cycles', 'Notes', 'Other'];
const TYPES = ['SELL', 'RENT', 'SWAP', 'FREE'];

module.exports = function listingRoutes(r, app) {
  const { db, catalog } = app;
  const one = id => { const row = db.get(`${LISTING_SQL} WHERE l.id = ?`, id); return row ? listingDto(row) : null; };
  const owned = ctx => {
    const row = db.get('SELECT * FROM listings WHERE id = ?', ctx.params.id);
    if (!row) throw new HttpError(404, 'Item not found.');
    if (row.seller_id !== ctx.user.id) throw new HttpError(403, 'Only the seller can change this listing.');
    return row;
  };

  /* browse + search. Filters: q, category, type, max, branch, sem, book, sort (new | low | high | sem) */
  r.get('/api/listings', ctx => {
    const q = ctx.query, where = [], args = [];
    if (q.q) { where.push("instr(lower(l.title || ' ' || l.description || ' ' || l.location), ?) > 0"); args.push(String(q.q).toLowerCase().slice(0, 100)); }
    if (q.category) { where.push('l.category = ?'); args.push(q.category); }
    if (q.type) { where.push('l.type = ?'); args.push(q.type); }
    if (q.max !== undefined && q.max !== '' && !Number.isNaN(+q.max)) { where.push('l.price <= ?'); args.push(+q.max); }
    if (q.book) { where.push('l.book_id = ?'); args.push(q.book); }
    let rows = db.all(`${LISTING_SQL} ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY l.created_at DESC LIMIT 500`, ...args).map(listingDto);
    const sem = +q.sem || 0;
    if (q.branch) rows = rows.filter(l => l.branches.includes('ALL') || l.branches.includes(q.branch));
    if (sem) rows = rows.filter(l => l.sem === sem);
    if (q.sort === 'low') rows.sort((a, b) => a.price - b.price);
    else if (q.sort === 'high') rows.sort((a, b) => b.price - a.price);
    else if (q.sort === 'sem') rows.sort((a, b) => (a.sem || 99) - (b.sem || 99));
    return rows;
  });

  r.get('/api/recommendations', ctx => recommend(db, ctx.user, Math.min(+ctx.query.limit || 8, 24)), { auth: true });

  r.get('/api/listings/:id', ctx => {
    const l = one(ctx.params.id);
    if (!l) throw new HttpError(404, 'Item not found.');
    return l;
  });

  r.post('/api/listings', ctx => {
    const b = ctx.body, u = ctx.user;
    const title = str(b.title, 'Title', { max: 80 });
    const category = oneOf(b.category, CATEGORIES, 'Category'), type = oneOf(b.type, TYPES, 'Listing type');
    const location = str(b.location, 'Campus location', { max: 80 }), desc = str(b.desc, 'Description', { max: 1000, optional: true });
    const price = ['SELL', 'RENT'].includes(type) ? int(b.price, 'Price', { min: 0, max: 1_000_000, optional: true }) : 0;
    let rentUnit = null, deposit = 0;
    if (type === 'RENT') {
      rentUnit = oneOf(b.rentUnit, ['day', 'week', 'semester'], 'Rental period');
      deposit = int(b.deposit, 'Deposit', { min: 0, max: 1_000_000, optional: true });
    }
    let bookId = null, branch = '', sem = 0;
    if (b.bookId) {
      bookId = String(b.bookId);
      if (!db.get('SELECT 1 FROM books WHERE id = ?', bookId)) throw bad('That book is not in the catalog.');
    } else if (['Books', 'Notes'].includes(category)) {
      branch = b.branch ? oneOf(b.branch, Object.keys(catalog.BRANCHES), 'Branch') : '';
      sem = int(b.sem, 'Semester', { min: 0, max: 8, optional: true });
    }
    const id = newId('l');
    db.run(`INSERT INTO listings (id, title, category, type, price, description, location, seller_id, status, book_id, branch, sem, rent_unit, deposit, created_at)
            VALUES (?,?,?,?,?,?,?,?, 'AVAILABLE', ?,?,?,?,?,?)`, id, title, category, type, price, desc, location, u.id, bookId, branch, sem, rentUnit, deposit, Date.now());
    ctx.status = 201;
    return one(id);
  }, { auth: true });

  /* seller marks an item sold / available again */
  r.patch('/api/listings/:id', ctx => {
    const row = owned(ctx);
    const status = oneOf(ctx.body.status, ['AVAILABLE', 'SOLD'], 'Status');
    db.run('UPDATE listings SET status = ? WHERE id = ?', status, row.id);
    return one(row.id);
  }, { auth: true });

  r.delete('/api/listings/:id', ctx => {
    const row = owned(ctx);
    db.run('DELETE FROM listings WHERE id = ?', row.id); // orders and chats keep their own copy of the title
    return { ok: true };
  }, { auth: true });
};
