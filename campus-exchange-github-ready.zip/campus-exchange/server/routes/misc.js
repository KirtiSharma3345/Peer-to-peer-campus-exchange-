'use strict';
const rzp = require('../lib/razorpay');
const { LISTING_SQL, listingDto, ORDER_SQL, orderDto, REVIEW_SQL, reviewDto, ratingOf, recommend } = require('../lib/models');

module.exports = function miscRoutes(r, app) {
  const { db, config } = app;

  r.get('/api/health', () => ({ ok: true }));

  /* settings the browser needs (the Razorpay *key id* is public; the secret never leaves the server) */
  r.get('/api/config', () => ({ razorpayKeyId: rzp.enabled(config) ? config.razorpay.keyId : null }));

  /* everything the Dashboard page shows, in one request */
  r.get('/api/dashboard', ctx => {
    const u = ctx.user;
    return {
      mine: db.all(`${LISTING_SQL} WHERE l.seller_id = ? ORDER BY l.created_at DESC`, u.id).map(listingDto),
      sales: db.all(`${ORDER_SQL} WHERE o.seller_id = ? ORDER BY o.created_at DESC`, u.id).map(orderDto),
      buys: db.all(`${ORDER_SQL} WHERE o.buyer_id = ? ORDER BY o.created_at DESC`, u.id).map(orderDto),
      received: db.all(`${REVIEW_SQL} WHERE r.seller_id = ? ORDER BY r.created_at DESC`, u.id).map(reviewDto),
      given: db.all(`${REVIEW_SQL} WHERE r.buyer_id = ? ORDER BY r.created_at DESC`, u.id).map(reviewDto),
      rating: ratingOf(db, u.id),
      recommended: recommend(db, u, 8),
    };
  }, { auth: true });
};
