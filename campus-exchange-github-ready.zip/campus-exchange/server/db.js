'use strict';
/* SQLite database (Node's built-in node:sqlite module - nothing to install). */
const fs = require('node:fs');
const path = require('node:path');

let DatabaseSync;
try { ({ DatabaseSync } = require('node:sqlite')); } catch {
  console.error(`\n✖ This project needs Node.js 22.13 or newer (it uses the built-in SQLite module).\n  You are running ${process.version}. Download the LTS version from https://nodejs.org\n`);
  process.exit(1);
}

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  name        TEXT NOT NULL,
  email       TEXT NOT NULL UNIQUE COLLATE NOCASE,
  pass_hash   TEXT NOT NULL,
  hostel      TEXT NOT NULL DEFAULT '',
  branch      TEXT NOT NULL DEFAULT '',
  sem         INTEGER NOT NULL DEFAULT 0,
  is_demo     INTEGER NOT NULL DEFAULT 0,
  created_at  INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  token_hash  TEXT PRIMARY KEY,
  user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at  INTEGER NOT NULL,
  expires_at  INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);

CREATE TABLE IF NOT EXISTS password_resets (
  user_id           INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  code_hash         TEXT NOT NULL,
  expires_at        INTEGER NOT NULL,
  tries             INTEGER NOT NULL DEFAULT 0,
  reset_token_hash  TEXT,
  sent_at           INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS books (
  id         TEXT PRIMARY KEY,
  title      TEXT NOT NULL,
  author     TEXT NOT NULL,
  publisher  TEXT NOT NULL DEFAULT '',
  subject    TEXT NOT NULL DEFAULT 'General',
  sem        INTEGER NOT NULL,
  branches   TEXT NOT NULL,                       -- JSON array, e.g. ["CSE","AI"] or ["ALL"]
  custom     INTEGER NOT NULL DEFAULT 0,          -- 1 = added by a student
  added_by   INTEGER REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS listings (
  id           TEXT PRIMARY KEY,
  title        TEXT NOT NULL,
  category     TEXT NOT NULL,
  type         TEXT NOT NULL,                     -- SELL | RENT | SWAP | FREE
  price        INTEGER NOT NULL DEFAULT 0,
  description  TEXT NOT NULL DEFAULT '',
  location     TEXT NOT NULL,
  seller_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status       TEXT NOT NULL DEFAULT 'AVAILABLE', -- AVAILABLE | SOLD
  book_id      TEXT REFERENCES books(id) ON DELETE SET NULL,
  branch       TEXT NOT NULL DEFAULT '',
  sem          INTEGER NOT NULL DEFAULT 0,
  rent_unit    TEXT,
  deposit      INTEGER NOT NULL DEFAULT 0,
  is_demo      INTEGER NOT NULL DEFAULT 0,
  created_at   INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_listings_created ON listings(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_listings_seller  ON listings(seller_id);
CREATE INDEX IF NOT EXISTS idx_listings_book    ON listings(book_id);

CREATE TABLE IF NOT EXISTS chats (
  id          TEXT PRIMARY KEY,
  listing_id  TEXT REFERENCES listings(id) ON DELETE SET NULL,
  title       TEXT NOT NULL,
  buyer_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  seller_id   INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at  INTEGER NOT NULL,
  UNIQUE (listing_id, buyer_id)
);
CREATE TABLE IF NOT EXISTS messages (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  chat_id     TEXT NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
  sender_id   INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  text        TEXT NOT NULL,
  created_at  INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_messages_chat ON messages(chat_id, id);

CREATE TABLE IF NOT EXISTS orders (
  id          TEXT PRIMARY KEY,
  ref         TEXT NOT NULL,
  listing_id  TEXT REFERENCES listings(id) ON DELETE SET NULL,
  title       TEXT NOT NULL,                      -- snapshot, so the order survives if the listing is deleted
  type        TEXT NOT NULL,
  price       INTEGER NOT NULL,
  qty         INTEGER NOT NULL DEFAULT 1,
  unit        TEXT,
  deposit     INTEGER NOT NULL DEFAULT 0,
  amount      INTEGER NOT NULL,
  method      TEXT NOT NULL,                      -- label only, e.g. "UPI · name@okaxis" (never card numbers)
  status      TEXT NOT NULL,                      -- PAID | PAY_ON_MEETUP
  buyer_id    INTEGER NOT NULL REFERENCES users(id),
  seller_id   INTEGER NOT NULL REFERENCES users(id),
  location    TEXT NOT NULL,
  created_at  INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_orders_buyer  ON orders(buyer_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_orders_seller ON orders(seller_id, created_at DESC);

CREATE TABLE IF NOT EXISTS payments (               -- Razorpay orders created by this server
  id          TEXT PRIMARY KEY,                   -- Razorpay order id
  listing_id  TEXT NOT NULL,
  user_id     INTEGER NOT NULL REFERENCES users(id),
  qty         INTEGER NOT NULL,
  amount      INTEGER NOT NULL,                   -- rupees
  used        INTEGER NOT NULL DEFAULT 0,
  created_at  INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS reviews (
  id          TEXT PRIMARY KEY,
  order_id    TEXT REFERENCES orders(id) ON DELETE SET NULL,
  listing_id  TEXT,
  title       TEXT NOT NULL,
  seller_id   INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  buyer_id    INTEGER REFERENCES users(id) ON DELETE SET NULL,
  buyer_name  TEXT NOT NULL,
  rating      INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
  text        TEXT NOT NULL DEFAULT '',
  is_demo     INTEGER NOT NULL DEFAULT 0,
  created_at  INTEGER NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_review_order ON reviews(order_id) WHERE order_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_reviews_seller ON reviews(seller_id);
`;

function openDb(file) {
  if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true });
  const raw = new DatabaseSync(file);
  raw.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;');
  raw.exec(SCHEMA);

  const cache = new Map();
  const stmt = sql => { let s = cache.get(sql); if (!s) { s = raw.prepare(sql); cache.set(sql, s); } return s; };
  const bind = p => p.map(v => (v === undefined ? null : typeof v === 'boolean' ? +v : v));

  return {
    raw,
    get: (sql, ...p) => stmt(sql).get(...bind(p)),
    all: (sql, ...p) => stmt(sql).all(...bind(p)),
    run: (sql, ...p) => stmt(sql).run(...bind(p)),
    exec: sql => raw.exec(sql),
    /** Runs fn() atomically. fn must be synchronous so no other request can interleave. */
    tx(fn) {
      raw.exec('BEGIN IMMEDIATE');
      try { const out = fn(); raw.exec('COMMIT'); return out; }
      catch (err) { try { raw.exec('ROLLBACK'); } catch { /* already rolled back */ } throw err; }
    },
    close: () => raw.close(),
  };
}

module.exports = { openDb };
