'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const { loadConfig } = require('./config');
const { openDb } = require('./db');
const { loadCatalogFile, seedCatalog, seedDemo } = require('./seed');
const { Router, HttpError, parseCookies, serializeCookie, sendJson, sendText, secureHeaders, readJson, serveStatic, createLimiter } = require('./lib/http');
const { createSessions } = require('./lib/sessions');
const { createMailer } = require('./lib/mailer');

const MUTATING = new Set(['POST', 'PATCH', 'PUT', 'DELETE']);

/** The secret used to sign OTPs: APP_SECRET if set, otherwise generated once and kept next to the database. */
function getSecret(config) {
  if (config.appSecret) return config.appSecret;
  if (config.dbFile === ':memory:') return crypto.randomBytes(32).toString('hex');
  const file = path.join(path.dirname(config.dbFile), '.app-secret');
  try { return fs.readFileSync(file, 'utf8').trim(); } catch { /* first run */ }
  const s = crypto.randomBytes(32).toString('hex');
  fs.writeFileSync(file, s, { mode: 0o600 });
  return s;
}

function createApp(overrides = {}) {
  const config = loadConfig(overrides);
  const db = openDb(config.dbFile);
  const catalog = loadCatalogFile(path.join(config.publicDir, 'js', 'books-db.js'));
  seedCatalog(db, catalog);
  if (config.seedDemo) seedDemo(db, catalog);

  const app = { config, db, catalog, secret: getSecret(config), limit: createLimiter(), mailer: createMailer(config), sessions: createSessions(db, config) };
  const router = new Router();
  for (const name of ['auth', 'books', 'listings', 'chats', 'orders', 'reviews', 'misc']) require(`./routes/${name}`)(router, app);

  const clientIp = req => (config.trustProxy && String(req.headers['x-forwarded-for'] || '').split(',')[0].trim()) || req.socket.remoteAddress || 'unknown';

  /* Same site, any origin listed in CORS_ORIGINS, or (outside production) any localhost port - e.g. VS Code Live Server on :5500 */
  const originAllowed = (origin, req) => {
    let u; try { u = new URL(origin); } catch { return false; }
    return u.host === req.headers.host || config.corsOrigins.includes(origin) || (!config.production && /^(localhost|127\.0\.0\.1)$/.test(u.hostname));
  };

  async function handleApi(req, res, url) {
    const origin = req.headers.origin, allowed = !!origin && originAllowed(origin, req);
    if (allowed) {
      res.setHeader('Access-Control-Allow-Origin', origin);
      res.setHeader('Access-Control-Allow-Credentials', 'true');
      res.setHeader('Vary', 'Origin');
    }
    if (req.method === 'OPTIONS') { // browser preflight for cross-port requests
      if (!allowed) return sendJson(res, 403, { error: 'Cross-site request blocked.' });
      res.writeHead(204, { 'Access-Control-Allow-Methods': 'GET,POST,PATCH,DELETE,OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type', 'Access-Control-Max-Age': '600' });
      return res.end();
    }
    const m = router.find(req.method, url.pathname);
    if (!m) return sendJson(res, 404, { error: 'Not found.' });
    if (m.methodNotAllowed) return sendJson(res, 405, { error: 'Method not allowed.' });

    const cookiesOut = [];
    const ctx = {
      req, res, params: m.params, query: Object.fromEntries(url.searchParams), body: {}, user: null, status: 200, ip: clientIp(req),
      cookies: parseCookies(req.headers.cookie),
      setCookie: (name, value, opts) => cookiesOut.push(serializeCookie(name, value, opts)),
    };
    try {
      if (MUTATING.has(req.method)) {
        // CSRF defence: JSON-only bodies + the Origin header (if the browser sends one) must be this site
        if (origin && !allowed) throw new HttpError(403, 'Cross-site request blocked.');
        ctx.body = await readJson(req);
      }
      ctx.user = app.sessions.lookup(ctx.cookies[app.sessions.COOKIE]);
      if (m.route.opts.auth && !ctx.user) throw new HttpError(401, 'Please log in first.');
      const out = await m.route.handler(ctx);
      sendJson(res, ctx.status, out === undefined ? { ok: true } : out, cookiesOut);
    } catch (err) {
      if (err instanceof HttpError) return sendJson(res, err.status, { error: err.message }, cookiesOut);
      console.error(`[error] ${req.method} ${url.pathname}`, err);
      sendJson(res, 500, { error: 'Something went wrong on the server.' });
    }
  }

  const server = http.createServer(async (req, res) => {
    const started = Date.now();
    secureHeaders(res);
    if (config.logRequests) res.on('finish', () => console.log(`${req.method} ${req.url} ${res.statusCode} ${Date.now() - started}ms`));
    try {
      const url = new URL(req.url, 'http://localhost');
      if (url.pathname.startsWith('/api/')) await handleApi(req, res, url);
      else await serveStatic(req, res, url.pathname, config.publicDir);
    } catch (err) {
      console.error('[error]', err);
      if (!res.headersSent) sendText(res, 500, 'Server error'); else res.end();
    }
  });

  const sweep = setInterval(() => { try { app.sessions.sweep(); } catch { /* db closed */ } }, 3600e3);
  sweep.unref();
  app.sessions.sweep();

  const close = () => new Promise(resolve => {
    clearInterval(sweep); app.limit.stop();
    server.close(() => { try { db.close(); } catch { /* already closed */ } resolve(); });
    server.closeAllConnections?.();
  });
  return { server, app, config, close };
}

if (require.main === module) {
  const { server, config, app, close } = createApp();
  server.listen(config.port, config.host, () => {
    const shown = config.host === '0.0.0.0' ? 'localhost' : config.host;
    console.log(`\n  Campus Exchange is running →  http://${shown}:${config.port}`);
    console.log(`  Database: ${config.dbFile}`);
    console.log(`  Payments: ${require('./lib/razorpay').enabled(config) ? 'Razorpay (live/test keys)' : 'demo gateway (no real money)'}`);
    console.log(`  OTP e-mail: ${app.mailer.live ? 'SMTP' : config.showOtp ? 'shown on screen + console (development)' : 'NOT configured'}\n`);
  });
  server.on('error', err => { console.error(err.code === 'EADDRINUSE' ? `\n✖ Port ${config.port} is already in use. Set another one, e.g. PORT=3001\n` : err); process.exit(1); });
  for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => close().then(() => process.exit(0)));
}

module.exports = { createApp };
