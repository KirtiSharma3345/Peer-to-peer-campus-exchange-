'use strict';
/* Fills an empty database with the textbook catalog and (optionally) demo listings, so the site is never empty. */
const fs = require('node:fs');
const vm = require('node:vm');
const { newId } = require('./lib/security');

/** The catalog lives in public/js/books-db.js (shared with the browser). We read it here instead of copying it. */
function loadCatalogFile(file) {
  if (!fs.existsSync(file)) throw new Error(`Catalog file not found: ${file}\nKeep your front-end in the "public" folder (public/js/books-db.js).`);
  const src = fs.readFileSync(file, 'utf8');
  const out = vm.runInNewContext(`${src}\n;({ BRANCHES, BOOKS_SEED, BOOKS_VERSION })`, Object.create(null), { filename: file, timeout: 2000 });
  return JSON.parse(JSON.stringify(out));
}

/** Loads / refreshes the built-in textbooks whenever BOOKS_VERSION in books-db.js changes. Student-added books are kept. */
function seedCatalog(db, catalog) {
  const version = String(catalog.BOOKS_VERSION);
  const cur = db.get("SELECT value FROM meta WHERE key = 'books_version'");
  if (cur && cur.value === version) return;
  db.tx(() => {
    for (const b of catalog.BOOKS_SEED) {
      db.run(`INSERT INTO books (id, title, author, publisher, subject, sem, branches, custom) VALUES (?,?,?,?,?,?,?,0)
              ON CONFLICT(id) DO UPDATE SET title = excluded.title, author = excluded.author, publisher = excluded.publisher,
              subject = excluded.subject, sem = excluded.sem, branches = excluded.branches WHERE books.custom = 0`,
        b.id, b.title, b.author, b.publisher || '', b.subject || 'General', b.sem, JSON.stringify(b.branches));
    }
    const keep = new Set(catalog.BOOKS_SEED.map(b => b.id));
    for (const { id } of db.all('SELECT id FROM books WHERE custom = 0')) {
      if (!keep.has(id) && !db.get('SELECT 1 FROM listings WHERE book_id = ?', id)) db.run('DELETE FROM books WHERE id = ?', id);
    }
    db.run("INSERT INTO meta (key, value) VALUES ('books_version', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value", version);
  });
}

const SELLERS = ['Aman Verma', 'Neha Singh', 'Rohit Das', 'Priya Nair', 'Karan Mehta', 'Sneha Roy', 'Vikas Jha', 'Isha Gupta'];
const demoEmail = name => name.toLowerCase().replace(/\W/g, '') + '@demo.campus';

function seedDemo(db, catalog) {
  if (db.get("SELECT 1 FROM meta WHERE key = 'demo_seeded'")) return;
  const book = title => catalog.BOOKS_SEED.find(b => b.title === title);
  const now = Date.now(), ago = () => Math.floor(now - Math.random() * 6e8);

  db.tx(() => {
    const uid = {};
    for (const name of SELLERS) {
      // pass_hash "!" can never match a real hash, so nobody can log in as a demo seller
      uid[name] = db.run('INSERT INTO users (name, email, pass_hash, is_demo, created_at) VALUES (?,?,?,1,?)', name, demoEmail(name), '!', now).lastInsertRowid;
    }
    const add = (title, category, type, price, desc, location, seller, x = {}) => db.run(
      `INSERT INTO listings (id, title, category, type, price, description, location, seller_id, status, book_id, branch, sem, rent_unit, deposit, is_demo, created_at)
       VALUES (?,?,?,?,?,?,?,?, 'AVAILABLE', ?,?,?,?,?,1,?)`,
      newId('l'), title, category, type, price, desc, location, uid[seller], x.bookId || null, x.branch || '', x.sem || 0, x.rentUnit || null, x.deposit || 0, ago());

    add('Engineering Mathematics – B.S. Grewal', 'Books', 'SELL', 350, 'Latest edition, no markings. Very good condition.', 'Library Gate', 'Aman Verma', { bookId: book('Higher Engineering Mathematics').id });
    add('Casio fx-991EX Calculator', 'Electronics', 'RENT', 20, 'Rent for exam days. Refundable deposit.', 'Hostel Block B', 'Neha Singh', { rentUnit: 'day', deposit: 200 });
    add('Hostel Study Table', 'Furniture', 'SELL', 1200, 'Sturdy wooden table, 2 drawers. Pickup only.', 'Hostel Block A', 'Rohit Das');
    add('Hero Sprint Cycle', 'Cycles', 'SELL', 2800, '21-gear cycle, recently serviced. Lock included.', 'Main Gate', 'Priya Nair');
    add('Arduino Uno Starter Kit', 'Lab Gear', 'RENT', 60, 'Board + sensors + jumper wires.', 'ECE Department', 'Karan Mehta', { rentUnit: 'week', deposit: 300 });
    add('Data Structures Handwritten Notes', 'Notes', 'FREE', 0, 'Complete semester notes, scanned + hard copy.', 'CSE Block', 'Sneha Roy', { branch: 'CSE', sem: 3 });
    add('Physics Lab Coat (M)', 'Lab Gear', 'SWAP', 0, 'Swap for a size L coat or a drawing board.', 'Hostel Block C', 'Vikas Jha');
    add('Boat Bluetooth Headphones', 'Electronics', 'SELL', 900, 'Works perfectly, 6 months old, box available.', 'Canteen', 'Isha Gupta');

    const addBook = (title, type, price, location, seller, desc, x = {}) => {
      const b = book(title); if (b) add(b.title, 'Books', type, price, desc, location, seller, { bookId: b.id, ...x });
    };
    addBook('Concepts of Physics', 'SELL', 300, 'Hostel Block A', 'Aman Verma', 'Both volumes, good condition.');
    addBook('Engineering Chemistry', 'FREE', 0, 'Hostel Block C', 'Vikas Jha', 'Giving away – just collect it from the hostel.');
    addBook('Data Structures Using C', 'SELL', 280, 'CSE Block', 'Sneha Roy', 'Clean copy, a few pencil notes.');
    addBook('Discrete Mathematics and Its Applications', 'SELL', 450, 'Library Gate', 'Aman Verma', 'Indian edition, no torn pages.');
    addBook('Database System Concepts', 'SELL', 600, 'CSE Block', 'Karan Mehta', 'Semester 4 DBMS book, like new.');
    addBook('Operating System Concepts', 'RENT', 40, 'Hostel Block B', 'Isha Gupta', 'Rent for the exam month.', { rentUnit: 'week', deposit: 200 });
    addBook('Introduction to Algorithms', 'SELL', 700, 'Library Gate', 'Vikas Jha', 'Hardbound, light highlighting.');
    addBook('Computer Networks', 'SELL', 500, 'Canteen', 'Rohit Das', 'Tanenbaum, 5th semester.');
    addBook('Artificial Intelligence: A Modern Approach', 'SELL', 650, 'Library Gate', 'Neha Singh', 'Excellent condition.');
    addBook('Hands-On Machine Learning with Scikit-Learn, Keras and TensorFlow', 'SELL', 900, 'Hostel Block B', 'Priya Nair', 'Useful for AI/ML projects.');
    addBook('Signals and Systems', 'SELL', 400, 'ECE Department', 'Karan Mehta', 'Oppenheim, some notes in margins.');
    addBook('Electronic Devices and Circuit Theory', 'SELL', 350, 'ECE Department', 'Karan Mehta', 'Boylestad, clean copy.');
    addBook('Engineering Thermodynamics', 'SELL', 380, 'Workshop', 'Rohit Das', 'P.K. Nag, good condition.');
    addBook('Surveying, Vol. 1', 'SELL', 300, 'Civil Block', 'Priya Nair', 'Punmia, third semester.');

    const review = (seller, buyer, rating, title, text) => db.run(
      'INSERT INTO reviews (id, order_id, listing_id, title, seller_id, buyer_id, buyer_name, rating, text, is_demo, created_at) VALUES (?,NULL,NULL,?,?,NULL,?,?,?,1,?)',
      newId('r'), title, uid[seller], buyer, rating, text, Math.floor(now - Math.random() * 3e8));
    review('Aman Verma', 'Rahul K.', 5, 'Engineering Mathematics – B.S. Grewal', 'Book was exactly as described. Met at the library gate on time.');
    review('Aman Verma', 'Ananya S.', 4, 'Concepts of Physics', 'Good condition, a little highlighting inside. Fair price.');
    review('Neha Singh', 'Mohit T.', 5, 'Casio fx-991EX Calculator', 'Worked perfectly for the exam and the deposit came back right away.');
    review('Priya Nair', 'Dev P.', 4, 'Hero Sprint Cycle', 'Well maintained cycle. Slight delay in meeting but very polite.');
    review('Karan Mehta', 'Simran K.', 5, 'Arduino Uno Starter Kit', 'Kit had everything I needed for my mini project.');
    review('Sneha Roy', 'Arjun M.', 5, 'Data Structures Handwritten Notes', 'Neat and complete notes. Very helpful before exams!');
    review('Isha Gupta', 'Kabir S.', 3, 'Boat Bluetooth Headphones', 'Headphones are fine but the box was missing.');
    review('Rohit Das', 'Nikhil R.', 4, 'Hostel Study Table', 'Sturdy table and a smooth pickup.');

    db.run("INSERT INTO meta (key, value) VALUES ('demo_seeded', '1')");
  });
}

module.exports = { loadCatalogFile, seedCatalog, seedDemo };
