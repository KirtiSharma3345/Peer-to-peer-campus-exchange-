# Campus Exchange – Backend + Database

Your existing site (HTML / CSS / JS) now has a real backend: **Node.js + SQLite**.
Nothing to `npm install` – the server uses only what ships with Node.

```
campus-exchange/
├── server/            ← the backend (API, database, security)
│   ├── index.js         starts the server, serves /public, routes /api
│   ├── db.js            SQLite schema (users, listings, chats, orders, reviews …)
│   ├── seed.js          loads the book catalog + demo listings on first run
│   ├── routes/          auth · books · listings · chats · orders · reviews · misc
│   └── lib/             http router, passwords, sessions, validation, Razorpay, mail
├── public/            ← your front-end (same pages; only js/app.js changed)
├── test/api.test.js   ← 55 automated tests          (npm test)
├── data/              ← campus.db is created here   (back this up!)
└── .env.example       ← optional settings
```

## Run it

1. Install **Node.js 22.13 or newer** (LTS) from https://nodejs.org – check with `node -v`.
2. In this folder:
   ```
   npm start
   ```
3. Open **http://localhost:3000** (open it from this address – not by double-clicking the HTML files).

`npm run dev` restarts automatically when you edit server files. `npm test` runs the tests.

## If the page says it cannot reach the server

1. Is the server running? You should see `Campus Exchange is running → http://127.0.0.1:3000` in the terminal.
2. Open **http://localhost:3000** (the server serves the pages itself – this is the most reliable way).
3. Using VS Code **Live Server** (port 5500) or another static server? That now works too: the pages automatically
   find the API on port 3000 of the same host (use `localhost` for both, not a mix of `localhost` and `127.0.0.1`).
   For another address, add `<script>window.CX_API = 'http://host:port'</script>` before `books-db.js`, and list the page's address in `CORS_ORIGINS` in `.env`.
4. Double-clicking an HTML file (`file://`) cannot work with login cookies – the page now says so instead of failing silently.
5. Port 3000 busy? Start with `PORT=3001 npm start` (Windows PowerShell: `$env:PORT=3001; npm start`).

## What changed in the front-end

Only `public/js/app.js` was rewritten. Every page, class name and style is the same, so the UI looks identical –
but instead of `localStorage`, it calls the API. `books-db.js` is unchanged and is still the **single source of the catalog**:
edit it, raise `BOOKS_VERSION`, restart the server, and the database refreshes (student-added books are kept).

## What the backend does (and the browser can no longer fake)

| Area | Server-side behaviour |
|---|---|
| Accounts | Passwords stored as **scrypt hashes**. Login uses an HttpOnly session cookie; only a hash of the token is stored. Optional college-email-only registration. |
| Brute force | 8 failed logins per e-mail per 15 min → locked. OTP: 5 tries, 5-min expiry, 30-s resend wait. |
| Forgot password | OTP is generated and checked on the server → one-time reset token → new password. Resetting signs out every other session. |
| Listings | Only the seller can edit/mark sold/delete. All input validated. |
| Checkout | Price is **recomputed on the server**; the sale is one atomic transaction, so two people can never buy the same item. Card numbers are never stored. |
| Payments | Demo gateway by default. With Razorpay keys, the server creates the order and **verifies the payment signature** before marking anything PAID. |
| Reviews | Only the buyer of a PAID order, one per order. |
| Chat | Only the buyer and seller can read a conversation. Demo sellers auto-reply. |
| Privacy | Other students' e-mail addresses are never sent to the browser. |
| CSRF / safety | JSON-only writes + Origin check, request size limit, static-file path-traversal protection. |

## API (all under `/api`)

```
POST /auth/register · /auth/login · /auth/logout     GET /auth/me        PATCH /users/me
POST /auth/forgot · /auth/verify-otp · /auth/reset-password
GET  /books   POST /books   DELETE /books/:id
GET  /listings?q=&category=&type=&max=&branch=&sem=&book=&sort=     GET /listings/:id
POST /listings   PATCH /listings/:id {status}   DELETE /listings/:id     GET /recommendations
GET  /chats   POST /chats {listingId}   GET /chats/:id   GET /chats/:id/messages?after=   POST /chats/:id/messages
POST /orders   GET /orders?role=buy|sell   POST /orders/:id/confirm   POST /payments/razorpay/order
GET  /reviews?seller=   POST /reviews   DELETE /reviews/:id
GET  /dashboard   GET /config   GET /health
```

## Settings (optional – copy `.env.example` to `.env`)

* **Real payments**: put `RAZORPAY_KEY_ID` and `RAZORPAY_KEY_SECRET` in `.env`. Checkout switches to Razorpay automatically.
* **Real OTP e-mails**: `npm install nodemailer`, fill `SMTP_*`, set `DEV_SHOW_OTP=false`.
  Without this, the OTP is shown on the login page and printed in the server console (fine for demos).
* **Demo data off**: `SEED_DEMO_DATA=false` (a fresh install then starts empty).
* **Reset everything**: stop the server and delete the `data/` folder.

## Putting it online

Set `NODE_ENV=production`, `HOST=0.0.0.0`, `TRUST_PROXY=true` (behind a proxy), serve over **HTTPS**
(cookies become Secure-only), and keep `data/` on persistent storage. Production never shows OTPs on screen,
so configure SMTP first. Free "serverless" hosts with temporary disks will lose the database – use a host with a persistent disk/volume.

## Honest limits

* The demo payment methods (UPI/Card/Net Banking) charge nothing and the server trusts them – use Razorpay mode for real money.
* Rate limits and chat polling (every 2.5 s) are per-process, which suits one server. Many servers would need Redis / WebSockets.
* SQLite is ideal for a campus-size app; if you outgrow it, only `server/db.js` and the SQL strings need to change.
* The e-mail (nodemailer) and live-Razorpay paths could not be tested against the real services here; the Razorpay logic is tested against a mock of its API, including forged-signature and replay attempts.
