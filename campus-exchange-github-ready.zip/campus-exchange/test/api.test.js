'use strict';
/* Run with:  npm test
   Starts the real server on a random port with an in-memory database and talks to it over HTTP. */
const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const crypto = require('node:crypto');
const { createApp } = require('../server');

const BASE_CFG = { dbFile: ':memory:', port: 0, logRequests: false, demoReplyDelayMs: 50, host: '127.0.0.1' };

async function boot(extra = {}) {
  const inst = createApp({ ...BASE_CFG, ...extra });
  await new Promise(ok => inst.server.listen(0, '127.0.0.1', ok));
  inst.base = `http://127.0.0.1:${inst.server.address().port}`;
  return inst;
}

/** A tiny browser: keeps the session cookie between requests. */
function browser(base) {
  let cookie = '';
  async function call(method, path, body, headers = {}) {
    const res = await fetch(base + '/api' + path, {
      method,
      headers: { ...(method !== 'GET' ? { 'Content-Type': 'application/json' } : {}), ...(cookie ? { cookie } : {}), ...headers },
      body: method === 'GET' ? undefined : JSON.stringify(body ?? {}),
    });
    const sc = res.headers.getSetCookie();
    if (sc.length) { const c = sc[0].split(';')[0]; cookie = c.endsWith('=') ? '' : c; }
    let data = null; try { data = await res.json(); } catch { /* no body */ }
    return { status: res.status, data, headers: res.headers };
  }
  return { call, get: p => call('GET', p), post: (p, b) => call('POST', p, b), patch: (p, b) => call('PATCH', p, b), del: p => call('DELETE', p), cookie: () => cookie };
}

const sleep = ms => new Promise(r => setTimeout(r, ms));
async function signup(base, name, email, extra = {}) {
  const b = browser(base);
  const r = await b.post('/auth/register', { name, email, password: 'secret1', branch: 'AI', sem: 3, ...extra });
  assert.equal(r.status, 201, JSON.stringify(r.data));
  const l = await b.post('/auth/login', { email, password: 'secret1' });
  assert.equal(l.status, 200);
  b.user = l.data.user;
  return b;
}
const listingBody = (o = {}) => ({ title: 'Test Book', category: 'Books', type: 'SELL', price: 250, desc: 'good', location: 'Library', ...o });

describe('Campus Exchange API', () => {
  let srv, anon, alice, bob, aliceListing;
  before(async () => {
    srv = await boot();
    anon = browser(srv.base);
    alice = await signup(srv.base, 'Alice Seller', 'alice@college.ac.in');
    bob = await signup(srv.base, 'Bob Buyer', 'bob@college.ac.in', { branch: 'CSE', sem: 4 });
  });
  after(() => srv.close());

  describe('startup + seed data', () => {
    it('serves the catalog from books-db.js', async () => {
      const r = await anon.get('/books');
      assert.equal(r.status, 200);
      assert.ok(r.data.length > 60);
      const ds = r.data.find(b => b.id === 'data-structures-using-c');
      assert.deepEqual(ds.branches, ['CSE', 'AI']);
      assert.equal(ds.sem, 3);
      assert.ok(ds.copies >= 1, 'demo copy counted');
    });
    it('seeds demo listings without leaking e-mail addresses', async () => {
      const r = await anon.get('/listings');
      assert.ok(r.data.length >= 20);
      assert.ok(!JSON.stringify(r.data).includes('@demo.campus'));
      assert.equal(typeof r.data[0].seller, 'number');
    });
    it('demo seller accounts cannot be logged into', async () => {
      const r = await anon.post('/auth/login', { email: 'amanverma@demo.campus', password: '!' });
      assert.equal(r.status, 401);
    });
    it('search, filters and sorting work', async () => {
      assert.ok((await anon.get('/listings?q=cycle')).data.every(l => /cycle/i.test(l.title + l.desc + l.location)));
      assert.ok((await anon.get('/listings?type=RENT')).data.every(l => l.type === 'RENT'));
      assert.ok((await anon.get('/listings?max=300&sort=low')).data.every(l => l.price <= 300));
      const sem3 = (await anon.get('/listings?branch=AI&sem=3')).data;
      assert.ok(sem3.length > 0 && sem3.every(l => l.sem === 3 && (l.branches.includes('AI') || l.branches.includes('ALL'))));
      const prices = (await anon.get('/listings?sort=high')).data.map(l => l.price);
      assert.deepEqual(prices, [...prices].sort((a, b) => b - a));
    });
  });

  describe('auth', () => {
    it('rejects bad registrations', async () => {
      assert.equal((await anon.post('/auth/register', { name: 'X', email: 'nope', password: 'secret1' })).status, 400);
      assert.equal((await anon.post('/auth/register', { name: 'X', email: 'x@y.com', password: '123' })).status, 400);
      assert.equal((await anon.post('/auth/register', { name: 'X', email: 'x@y.com', password: 'secret1', branch: 'XYZ' })).status, 400);
    });
    it('rejects a duplicate e-mail (case-insensitive)', async () => {
      const r = await anon.post('/auth/register', { name: 'Dup', email: 'ALICE@college.ac.in', password: 'secret1' });
      assert.equal(r.status, 409);
    });
    it('wrong password -> 401, right password -> session cookie (HttpOnly)', async () => {
      assert.equal((await anon.post('/auth/login', { email: 'alice@college.ac.in', password: 'wrong' })).status, 401);
      const raw = await fetch(srv.base + '/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: 'alice@college.ac.in', password: 'secret1' }) });
      assert.match(raw.headers.get('set-cookie'), /cx_sid=.+HttpOnly.+SameSite=Lax/);
    });
    it('/auth/me reflects the session and never returns the password hash', async () => {
      const me = await alice.get('/auth/me');
      assert.equal(me.data.user.email, 'alice@college.ac.in');
      assert.ok(!JSON.stringify(me.data).includes('scrypt'));
      assert.equal((await anon.get('/auth/me')).data.user, null);
    });
    it('profile update validates the branch', async () => {
      assert.equal((await bob.patch('/users/me', { branch: 'ME', sem: 5, hostel: 'Block C' })).data.user.branch, 'ME');
      assert.equal((await bob.patch('/users/me', { branch: 'NOPE', sem: 5 })).status, 400);
      await bob.patch('/users/me', { branch: 'CSE', sem: 4, hostel: '' });
    });
    it('logout destroys the session on the server', async () => {
      const t = await signup(srv.base, 'Temp User', 'temp@college.ac.in');
      const old = t.cookie();
      await t.post('/auth/logout');
      const replay = await fetch(srv.base + '/api/auth/me', { headers: { cookie: old } });
      assert.equal((await replay.json()).user, null);
    });
    it('protected routes need a login', async () => {
      for (const [m, p] of [['GET', '/orders'], ['GET', '/chats'], ['GET', '/dashboard'], ['POST', '/listings'], ['POST', '/reviews']]) {
        assert.equal((await anon.call(m, p, {})).status, 401, `${m} ${p}`);
      }
    });
  });

  describe('request safety', () => {
    it('blocks cross-site requests (Origin header)', async () => {
      const r = await alice.call('POST', '/listings', listingBody(), { Origin: 'https://evil.example' });
      assert.equal(r.status, 403);
    });
    it('allows a localhost front-end on another port (Live Server) but not strangers', async () => {
      const pre = await fetch(srv.base + '/api/auth/login', { method: 'OPTIONS', headers: { Origin: 'http://localhost:5500', 'Access-Control-Request-Method': 'POST' } });
      assert.equal(pre.status, 204);
      assert.equal(pre.headers.get('access-control-allow-origin'), 'http://localhost:5500');
      assert.equal(pre.headers.get('access-control-allow-credentials'), 'true');
      const ok = await alice.call('GET', '/auth/me', undefined, { Origin: 'http://127.0.0.1:5500' });
      assert.equal(ok.headers.get('access-control-allow-origin'), 'http://127.0.0.1:5500');
      const evil = await fetch(srv.base + '/api/auth/login', { method: 'OPTIONS', headers: { Origin: 'https://evil.example' } });
      assert.equal(evil.status, 403);
      assert.equal(evil.headers.get('access-control-allow-origin'), null);
    });
    it('requires JSON bodies on writes', async () => {
      const res = await fetch(srv.base + '/api/auth/logout', { method: 'POST', headers: { 'Content-Type': 'text/plain' }, body: 'x' });
      assert.equal(res.status, 415);
    });
    it('rejects oversized and malformed JSON', async () => {
      const big = await fetch(srv.base + '/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: 'a', password: 'x'.repeat(200_000) }) });
      assert.equal(big.status, 413);
      const broken = await fetch(srv.base + '/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{oops' });
      assert.equal(broken.status, 400);
    });
    it('serves the front-end and refuses to leak files outside public/', async () => {
      const home = await fetch(srv.base + '/');
      assert.equal(home.status, 200);
      assert.match(await home.text(), /One Campus/);
      assert.equal((await fetch(srv.base + '/js/app.js')).status, 200);
      for (const p of ['/.env', '/../package.json', '/%2e%2e/package.json', '/css/..%5c..%5cpackage.json', '/server/index.js', '/nope.html']) {
        assert.equal((await fetch(srv.base + p)).status, 404, p);
      }
    });
  });

  describe('listings', () => {
    it('lets a student post a listing linked to a catalog book', async () => {
      const r = await alice.post('/listings', listingBody({ title: 'Machine Learning', bookId: 'machine-learning' }));
      assert.equal(r.status, 201);
      aliceListing = r.data;
      assert.equal(aliceListing.seller, alice.user.id);
      assert.deepEqual(aliceListing.branches, ['AI']);
      assert.equal(aliceListing.sem, 5);
    });
    it('validates input', async () => {
      assert.equal((await alice.post('/listings', listingBody({ title: '' }))).status, 400);
      assert.equal((await alice.post('/listings', listingBody({ type: 'BARTER' }))).status, 400);
      assert.equal((await alice.post('/listings', listingBody({ price: -5 }))).status, 400);
      assert.equal((await alice.post('/listings', listingBody({ bookId: 'no-such-book' }))).status, 400);
      assert.equal((await alice.post('/listings', listingBody({ type: 'RENT', rentUnit: 'year' }))).status, 400);
    });
    it('FREE/SWAP items always have price 0; RENT keeps unit + deposit', async () => {
      const free = await alice.post('/listings', listingBody({ type: 'FREE', price: 999 }));
      assert.equal(free.data.price, 0);
      const rent = await alice.post('/listings', listingBody({ type: 'RENT', price: 30, rentUnit: 'week', deposit: 100 }));
      assert.equal(rent.data.rentUnit, 'week'); assert.equal(rent.data.deposit, 100);
    });
    it('only the owner can change or delete it', async () => {
      assert.equal((await bob.patch(`/listings/${aliceListing.id}`, { status: 'SOLD' })).status, 403);
      assert.equal((await bob.del(`/listings/${aliceListing.id}`)).status, 403);
      assert.equal((await anon.patch(`/listings/${aliceListing.id}`, { status: 'SOLD' })).status, 401);
      const r = await alice.patch(`/listings/${aliceListing.id}`, { status: 'SOLD' });
      assert.equal(r.data.status, 'SOLD');
      await alice.patch(`/listings/${aliceListing.id}`, { status: 'AVAILABLE' });
    });
    it('404 for unknown items', async () => assert.equal((await anon.get('/listings/nope')).status, 404));
    it('recommends books for the student\'s branch & semester (and not their own)', async () => {
      const rec = (await bob.get('/recommendations?limit=20')).data; // Bob: CSE, sem 4
      assert.ok(rec.length > 0);
      assert.ok(rec.every(l => l.seller !== bob.user.id && ['Your semester', 'Next semester', 'Your branch'].includes(l.tag)));
      assert.ok(rec[0].tag === 'Your semester' && rec[0].sem === 4);
    });
  });

  describe('catalog', () => {
    it('adds and removes a custom book (owner only, not when listings use it)', async () => {
      const add = await alice.post('/books', { title: 'My Custom Book', author: 'A. Author', branch: 'CSE', sem: 2 });
      assert.equal(add.status, 201); assert.equal(add.data.custom, true);
      assert.equal((await alice.post('/books', { title: 'my custom book', author: 'a. author', branch: 'CSE', sem: 2 })).status, 409);
      assert.equal((await bob.del('/books/my-custom-book')).status, 403);
      await alice.post('/listings', listingBody({ title: 'My Custom Book', bookId: 'my-custom-book' }));
      assert.equal((await alice.del('/books/my-custom-book')).status, 409);
      const add2 = await alice.post('/books', { title: 'Another One', author: 'B. Author', branch: 'ALL', sem: 1 });
      assert.equal((await alice.del('/books/' + add2.data.id)).status, 200);
    });
    it('built-in books cannot be deleted', async () => assert.equal((await alice.del('/books/machine-learning')).status, 403));
  });

  describe('chat', () => {
    let chatId;
    it('buyer opens a chat once per listing; cannot chat on own listing', async () => {
      const c1 = await bob.post('/chats', { listingId: aliceListing.id });
      const c2 = await bob.post('/chats', { listingId: aliceListing.id });
      assert.equal(c1.data.id, c2.data.id);
      chatId = c1.data.id;
      assert.equal((await alice.post('/chats', { listingId: aliceListing.id })).status, 400);
    });
    it('both sides exchange messages; polling returns only new ones', async () => {
      const m1 = await bob.post(`/chats/${chatId}/messages`, { text: 'Is it available?' });
      await alice.post(`/chats/${chatId}/messages`, { text: 'Yes!' });
      const all = (await alice.get(`/chats/${chatId}`)).data;
      assert.equal(all.messages.length, 2);
      assert.equal(all.messages[0].from, bob.user.id);
      const newer = (await bob.get(`/chats/${chatId}/messages?after=${m1.data.id}`)).data.messages;
      assert.equal(newer.length, 1); assert.equal(newer[0].text, 'Yes!');
      assert.equal((await alice.get('/chats')).data[0].last.text, 'Yes!');
    });
    it('outsiders cannot read or write the chat', async () => {
      const eve = await signup(srv.base, 'Eve Outsider', 'eve@college.ac.in');
      assert.equal((await eve.get(`/chats/${chatId}`)).status, 404);
      assert.equal((await eve.post(`/chats/${chatId}/messages`, { text: 'hi' })).status, 404);
      assert.equal((await eve.get('/chats')).data.length, 0);
    });
    it('rejects empty and over-long messages', async () => {
      assert.equal((await bob.post(`/chats/${chatId}/messages`, { text: '   ' })).status, 400);
      assert.equal((await bob.post(`/chats/${chatId}/messages`, { text: 'x'.repeat(1001) })).status, 400);
    });
    it('demo sellers reply automatically', async () => {
      const demo = (await anon.get('/listings')).data.find(l => l.demo);
      const c = (await bob.post('/chats', { listingId: demo.id })).data;
      assert.equal(c.demo, true);
      await bob.post(`/chats/${c.id}/messages`, { text: 'Hello' });
      await sleep(300);
      const msgs = (await bob.get(`/chats/${c.id}`)).data.messages;
      assert.equal(msgs.length, 2); assert.equal(msgs[1].from, demo.seller);
    });
  });

  describe('orders (demo gateway) + reviews', () => {
    let order, codListing, codOrder;
    it('rejects invalid purchases', async () => {
      assert.equal((await alice.post('/orders', { listingId: aliceListing.id, method: 'upi', label: 'UPI' })).status, 400, 'own item');
      const free = (await alice.post('/listings', listingBody({ type: 'FREE' }))).data;
      assert.equal((await bob.post('/orders', { listingId: free.id, method: 'upi' })).status, 400, 'nothing to pay');
      assert.equal((await bob.post('/orders', { listingId: 'nope', method: 'upi' })).status, 404);
      assert.equal((await bob.post('/orders', { listingId: aliceListing.id, method: 'bitcoin' })).status, 400);
    });
    it('buys an item: server computes the amount, marks it SOLD, stores no card number', async () => {
      const r = await bob.post('/orders', { listingId: aliceListing.id, method: 'card', label: 'Visa ···· 1111', amount: 1 });
      assert.equal(r.status, 201, JSON.stringify(r.data));
      order = r.data;
      assert.equal(order.amount, 250); assert.equal(order.status, 'PAID'); assert.equal(order.method, 'Visa ···· 1111');
      assert.equal((await anon.get(`/listings/${aliceListing.id}`)).data.status, 'SOLD');
      const leak = await bob.post('/orders', { listingId: (await alice.post('/listings', listingBody())).data.id, method: 'card', label: '4111 1111 1111 1111' });
      assert.equal(leak.data.method, 'Card', 'a full card number must never be stored');
    });
    it('a second buyer cannot buy a sold item (no double sale)', async () => {
      const carol = await signup(srv.base, 'Carol', 'carol@college.ac.in');
      const r = await carol.post('/orders', { listingId: aliceListing.id, method: 'upi', label: 'UPI · c@okaxis' });
      assert.equal(r.status, 409);
    });
    it('simultaneous buyers: exactly one wins', async () => {
      const l = (await alice.post('/listings', listingBody({ title: 'Race item' }))).data;
      const others = await Promise.all([1, 2, 3, 4].map(i => signup(srv.base, `Racer ${i}`, `racer${i}@college.ac.in`)));
      const results = await Promise.all(others.map(b => b.post('/orders', { listingId: l.id, method: 'cod' })));
      assert.deepEqual(results.map(r => r.status).sort(), [201, 409, 409, 409]);
    });
    it('rental price = rent × duration + deposit', async () => {
      const l = (await alice.post('/listings', listingBody({ type: 'RENT', price: 40, rentUnit: 'week', deposit: 200 }))).data;
      const r = await bob.post('/orders', { listingId: l.id, method: 'upi', label: 'UPI', qty: 3 });
      assert.equal(r.data.amount, 40 * 3 + 200); assert.equal(r.data.unit, 'week'); assert.equal(r.data.qty, 3);
    });
    it('orders are visible to buyer and seller only', async () => {
      assert.ok((await bob.get('/orders?role=buy')).data.some(o => o.id === order.id));
      assert.ok((await alice.get('/orders?role=sell')).data.some(o => o.id === order.id));
      assert.ok(!(await alice.get('/orders?role=buy')).data.some(o => o.id === order.id));
      const eve = await signup(srv.base, 'Eve2', 'eve2@college.ac.in');
      assert.equal((await eve.get('/orders')).data.length, 0);
    });
    it('pay-on-meetup stays pending until the SELLER confirms', async () => {
      codListing = (await alice.post('/listings', listingBody({ title: 'COD item', price: 120 }))).data;
      codOrder = (await bob.post('/orders', { listingId: codListing.id, method: 'cod' })).data;
      assert.equal(codOrder.status, 'PAY_ON_MEETUP');
      assert.equal((await bob.post(`/orders/${codOrder.id}/confirm`)).status, 404, 'buyer cannot confirm');
      assert.equal((await alice.post(`/orders/${codOrder.id}/confirm`)).data.status, 'PAID');
      assert.equal((await alice.post(`/orders/${codOrder.id}/confirm`)).status, 404, 'already confirmed');
    });
    it('reviews: only the buyer, only after PAID, once per order', async () => {
      const pending = (await bob.post('/orders', { listingId: (await alice.post('/listings', listingBody({ price: 60 }))).data.id, method: 'cod' })).data;
      assert.equal((await bob.post('/reviews', { orderId: pending.id, rating: 5 })).status, 403, 'not paid yet');
      assert.equal((await alice.post('/reviews', { orderId: order.id, rating: 5 })).status, 403, 'seller cannot review self');
      assert.equal((await bob.post('/reviews', { orderId: order.id, rating: 9 })).status, 400);
      const ok = await bob.post('/reviews', { orderId: order.id, rating: 4, text: 'Great seller' });
      assert.equal(ok.status, 201); assert.equal(ok.data.buyerName, 'Bob Buyer');
      assert.equal((await bob.post('/reviews', { orderId: order.id, rating: 5 })).status, 409);
    });
    it('ratings roll up into listings and the public review list', async () => {
      const l = (await anon.get(`/listings/${aliceListing.id}`)).data;
      assert.deepEqual(l.sellerRating, { count: 1, avg: 4 });
      const reviews = (await anon.get(`/reviews?seller=${alice.user.id}`)).data;
      assert.equal(reviews.length, 1); assert.equal(reviews[0].text, 'Great seller');
      assert.ok((await bob.get('/orders?role=buy')).data.find(o => o.id === order.id).review.rating === 4);
    });
    it('only the author can delete a review', async () => {
      const id = (await anon.get(`/reviews?seller=${alice.user.id}`)).data[0].id;
      assert.equal((await alice.del(`/reviews/${id}`)).status, 404);
      assert.equal((await bob.del(`/reviews/${id}`)).status, 200);
    });
    it('orders survive when the listing is deleted', async () => {
      const l = (await alice.post('/listings', listingBody({ title: 'Will vanish' }))).data;
      const o = (await bob.post('/orders', { listingId: l.id, method: 'cod' })).data;
      await alice.patch(`/listings/${l.id}`, { status: 'AVAILABLE' });
      assert.equal((await alice.del(`/listings/${l.id}`)).status, 200);
      const kept = (await bob.get('/orders?role=buy')).data.find(x => x.id === o.id);
      assert.equal(kept.title, 'Will vanish'); assert.equal(kept.listingId, null);
    });
    it('dashboard bundles everything for the logged-in user', async () => {
      const d = (await alice.get('/dashboard')).data;
      for (const k of ['mine', 'sales', 'buys', 'received', 'given', 'rating', 'recommended']) assert.ok(k in d, k);
      assert.ok(d.mine.length >= 5 && d.sales.length >= 4);
    });
  });

  describe('forgot password (OTP)', () => {
    let otp;
    it('unknown e-mail -> 404', async () => assert.equal((await anon.post('/auth/forgot', { email: 'ghost@college.ac.in' })).status, 404));
    it('sends an OTP (shown in dev mode), throttles resend', async () => {
      const r = await anon.post('/auth/forgot', { email: 'bob@college.ac.in' });
      assert.equal(r.status, 200); assert.match(r.data.demoOtp, /^\d{6}$/);
      otp = r.data.demoOtp;
      assert.equal((await anon.post('/auth/forgot', { email: 'bob@college.ac.in' })).status, 429);
    });
    it('wrong OTP counts down attempts', async () => {
      const wrong = otp === '000000' ? '111111' : '000000';
      const r = await anon.post('/auth/verify-otp', { email: 'bob@college.ac.in', otp: wrong });
      assert.equal(r.status, 400); assert.match(r.data.error, /4 attempt/);
    });
    it('cannot reset the password without verifying the OTP first', async () => {
      const r = await anon.post('/auth/reset-password', { email: 'bob@college.ac.in', resetToken: 'guess', password: 'hacked1' });
      assert.equal(r.status, 400);
    });
    it('right OTP -> reset token -> new password; old password and old sessions stop working', async () => {
      const v = await anon.post('/auth/verify-otp', { email: 'bob@college.ac.in', otp });
      assert.equal(v.status, 200);
      assert.equal((await anon.post('/auth/reset-password', { email: 'bob@college.ac.in', resetToken: v.data.resetToken, password: 'short' })).status, 400);
      assert.equal((await anon.post('/auth/reset-password', { email: 'bob@college.ac.in', resetToken: v.data.resetToken, password: 'brandnew1' })).status, 200);
      assert.equal((await anon.post('/auth/login', { email: 'bob@college.ac.in', password: 'secret1' })).status, 401);
      assert.equal((await anon.post('/auth/login', { email: 'bob@college.ac.in', password: 'brandnew1' })).status, 200);
      assert.equal((await bob.get('/auth/me')).data.user, null, 'old session was signed out');
      assert.equal((await anon.post('/auth/reset-password', { email: 'bob@college.ac.in', resetToken: v.data.resetToken, password: 'again123' })).status, 400, 'token is single-use');
    });
    it('locks the OTP after 5 wrong tries', async () => {
      const c = browser(srv.base);
      await signup(srv.base, 'Lock Me', 'lock@college.ac.in');
      const f = await c.post('/auth/forgot', { email: 'lock@college.ac.in' });
      const wrong = f.data.demoOtp === '123456' ? '654321' : '123456';
      for (let i = 0; i < 5; i++) await c.post('/auth/verify-otp', { email: 'lock@college.ac.in', otp: wrong });
      assert.equal((await c.post('/auth/verify-otp', { email: 'lock@college.ac.in', otp: f.data.demoOtp })).status, 429);
    });
  });

  describe('brute-force protection', () => {
    it('locks login for an e-mail after repeated failures', async () => {
      await signup(srv.base, 'Target', 'target@college.ac.in');
      let last;
      for (let i = 0; i < 9; i++) last = await anon.post('/auth/login', { email: 'target@college.ac.in', password: 'bad' + i });
      assert.equal(last.status, 429);
      assert.equal((await anon.post('/auth/login', { email: 'target@college.ac.in', password: 'secret1' })).status, 429, 'even the right password waits');
    });
  });
});

describe('college e-mail rule', () => {
  it('enforces REQUIRE_COLLEGE_EMAIL on the server', async () => {
    const s = await boot({ requireCollegeEmail: true, seedDemo: false });
    const b = browser(s.base);
    assert.equal((await b.post('/auth/register', { name: 'G', email: 'g@gmail.com', password: 'secret1' })).status, 400);
    assert.equal((await b.post('/auth/register', { name: 'G', email: 'g@dvsiet.ac.in', password: 'secret1' })).status, 201);
    await s.close();
  });
});

describe('Razorpay mode', () => {
  let s, mock, b, seller, listing;
  const SECRET = 'test_secret_123';
  const sign = (orderId, paymentId) => crypto.createHmac('sha256', SECRET).update(`${orderId}|${paymentId}`).digest('hex');
  let counter = 0;

  before(async () => {
    // a fake Razorpay API so the test needs no internet and no real keys
    mock = http.createServer((req, res) => {
      let body = ''; req.on('data', c => { body += c; });
      req.on('end', () => {
        const ok = req.headers.authorization === 'Basic ' + Buffer.from('rzp_test_key:' + SECRET).toString('base64');
        res.writeHead(ok ? 200 : 401, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(ok ? { id: 'order_T' + ++counter, amount: JSON.parse(body).amount } : { error: { description: 'bad keys' } }));
      });
    });
    await new Promise(ok => mock.listen(0, '127.0.0.1', ok));
    s = await boot({ razorpay: { keyId: 'rzp_test_key', keySecret: SECRET, apiBase: `http://127.0.0.1:${mock.address().port}` }, seedDemo: false });
    seller = await signup(s.base, 'Seller', 'seller@college.ac.in');
    b = await signup(s.base, 'Buyer', 'buyer@college.ac.in');
    listing = (await seller.post('/listings', listingBody({ price: 500 }))).data;
  });
  after(async () => { await s.close(); await new Promise(ok => mock.close(ok)); });

  it('exposes only the public key id', async () => {
    const cfg = (await b.get('/config')).data;
    assert.equal(cfg.razorpayKeyId, 'rzp_test_key');
    assert.ok(!JSON.stringify(cfg).includes(SECRET));
  });
  it('rejects the demo gateway methods when live payments are on', async () => {
    assert.equal((await b.post('/orders', { listingId: listing.id, method: 'upi', label: 'UPI' })).status, 400);
  });
  it('creates a Razorpay order with the server-side amount (in paise)', async () => {
    const r = await b.post('/payments/razorpay/order', { listingId: listing.id, amount: 1 });
    assert.equal(r.status, 200, JSON.stringify(r.data));
    assert.equal(r.data.amount, 50000); assert.equal(r.data.orderId, 'order_T1'); assert.equal(r.data.keyId, 'rzp_test_key');
  });
  it('refuses a payment with a forged signature', async () => {
    const r = await b.post('/orders', { listingId: listing.id, method: 'online', razorpay: { orderId: 'order_T1', paymentId: 'pay_1', signature: 'f'.repeat(64) } });
    assert.equal(r.status, 400);
    assert.equal((await b.get(`/listings/${listing.id}`)).data.status, 'AVAILABLE');
  });
  it('refuses a validly-signed payment that belongs to someone else / another listing', async () => {
    const other = await signup(s.base, 'Other', 'other@college.ac.in');
    const r = await other.post('/orders', { listingId: listing.id, method: 'online', razorpay: { orderId: 'order_T1', paymentId: 'pay_2', signature: sign('order_T1', 'pay_2') } });
    assert.equal(r.status, 400);
  });
  it('accepts a correctly signed payment, marks PAID + SOLD, and it cannot be replayed', async () => {
    const r = await b.post('/orders', { listingId: listing.id, method: 'online', razorpay: { orderId: 'order_T1', paymentId: 'pay_3', signature: sign('order_T1', 'pay_3') } });
    assert.equal(r.status, 201, JSON.stringify(r.data));
    assert.equal(r.data.status, 'PAID'); assert.equal(r.data.ref, 'pay_3'); assert.equal(r.data.amount, 500);
    const l2 = (await seller.post('/listings', listingBody({ price: 500 }))).data;
    const replay = await b.post('/orders', { listingId: l2.id, method: 'online', razorpay: { orderId: 'order_T1', paymentId: 'pay_3', signature: sign('order_T1', 'pay_3') } });
    assert.equal(replay.status, 400, 'a used payment cannot buy a second item');
  });
});
