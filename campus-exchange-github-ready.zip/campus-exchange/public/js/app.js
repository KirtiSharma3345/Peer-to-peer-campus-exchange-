/* Peer-to-Peer Campus Exchange – front-end.
   All data lives on the server (Node.js + SQLite). This file only draws the pages and talks to the /api routes. */
const $ = (s, r = document) => r.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CATS = {Books:'📚', Electronics:'💻', 'Lab Gear':'🔬', Furniture:'🪑', Cycles:'🚲', Notes:'📝', Other:'📦'};

/* ---------- talking to the server ---------- */
/* Where the server is. Normally the same address as the page. If the pages are opened from another port (VS Code Live Server,
   `python -m http.server`...) we fall back to the server on port 3000 of the same host. Override with: window.CX_API = 'http://host:port' */
let API_BASE = window.CX_API || '';
async function findServer() {
  if (window.CX_API) return;
  if (location.protocol === 'file:') throw new Error('You opened the HTML file directly. Start the server (npm start) and open http://localhost:3000 instead.');
  for (const base of ['', `${location.protocol}//${location.hostname}:3000`]) {
    try { const r = await fetch(base + '/api/health', { credentials: 'include' }); if (r.ok && (await r.json()).ok) { API_BASE = base; return; } } catch { /* try the next address */ }
  }
  throw new Error('Cannot reach the server. Start it with: npm start (then open http://localhost:3000)');
}
async function api(path, { method = 'GET', body } = {}) {
  let res;
  try {
    res = await fetch(API_BASE + '/api' + path, {
      method, credentials: API_BASE ? 'include' : 'same-origin',
      headers: method === 'GET' ? {} : { 'Content-Type': 'application/json' },
      body: method === 'GET' ? undefined : JSON.stringify(body ?? {}),
    });
  } catch { throw new Error('Cannot reach the server. Is it running? (start it with: npm start)'); }
  let data = null; try { data = await res.json(); } catch { /* empty body */ }
  if (!res.ok) { const e = new Error((data && data.error) || `Request failed (${res.status})`); e.status = res.status; throw e; }
  return data;
}

/* things loaded once per page: server settings, the logged-in user, the book catalog */
let CFG = { razorpayKeyId: null }, USER = null, BOOKS = [];
const me = () => USER;
const books = () => BOOKS;
const refreshBooks = async () => { BOOKS = await api('/books'); };

/* ---------- layout ---------- */
function layout(page) {
  const u = me();
  const a = p => page === p ? 'active' : '';
  $('#nav').innerHTML = `<div class="nav"><div class="nav-in">
    <a class="logo" href="index.html">Campus<span>Exchange</span></a>
    <div class="links">
      <a class="${a('home')}" href="index.html">Browse</a>
      <a class="${a('catalog')}" href="books.html">Books</a>
      <a class="${a('post')}" href="post.html">Post Item</a>
      <a class="${a('chat')}" href="chat.html">Chat</a>
      <a class="${a('orders')}" href="orders.html">Orders</a>
      ${u ? `<a class="${a('dashboard')}" href="dashboard.html">Dashboard</a>` : ''}
      ${u ? `<span class="hello">Hi, ${esc(u.name.split(' ')[0])}</span><a href="#" id="logout">Logout</a>`
          : `<a class="${a('login')}" href="login.html">Login</a><a class="btn sm" href="register.html">Register</a>`}
    </div></div></div>`;
  $('#foot').innerHTML = `<div class="foot">Peer-to-Peer Campus Exchange · One campus. One marketplace.<br>Dewan VS Institute of Engineering and Technology · Dept. of AI</div>`;
  const lo = $('#logout');
  if (lo) lo.onclick = async e => { e.preventDefault(); try { await api('/auth/logout', { method: 'POST' }); } catch { /* ignore */ } location.href = 'index.html'; };
}
function toast(t) { const e = document.createElement('div'); e.className = 'toast'; e.textContent = t; document.body.append(e); setTimeout(() => e.remove(), 2600); }
function requireLogin() {
  if (!me()) { location.href = 'login.html?next=' + encodeURIComponent(location.pathname.split('/').pop() + location.search); return false; }
  return true;
}
/* wraps an event handler so a failed request shows a toast instead of failing silently */
const guard = fn => async (...args) => {
  try { await fn(...args); }
  catch (e) { if (e.status === 401) { USER = null; requireLogin(); } else toast(e.message); }
};
function fatal(e) { // the whole page could not load
  if (e && e.status === 401) return void requireLogin();
  const main = $('main');
  if (main) main.innerHTML = `<div class="panel empty">⚠ ${esc((e && e.message) || e)}<br><span class="meta">Open the site from the address the server prints (for example http://localhost:3000).</span></div>`;
}
const priceText = l => l.type === 'FREE' ? 'Free' : l.type === 'SWAP' ? 'Swap' : l.type === 'RENT' ? `₹${l.price}/${l.rentUnit || 'day'}` : `₹${l.price}`;
const ago = t => { const m = (Date.now() - t) / 6e4; return m < 1 ? 'just now' : m < 60 ? Math.floor(m) + ' min ago' : m < 1440 ? Math.floor(m / 60) + ' h ago' : Math.floor(m / 1440) + ' d ago'; };
const fmtTime = t => new Date(t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
const fmtDate = t => new Date(t).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' });
const rupee = n => '₹' + Number(n || 0).toLocaleString('en-IN');

/* ---------- book catalog + branch / semester helpers ---------- */
const branchText = arr => !arr || !arr.length ? '' : arr.includes('ALL') ? 'All branches (1st year)' : arr.join(' / ');
const branchOptions = (placeholder, withAll) => (placeholder ? `<option value="">${placeholder}</option>` : '')
  + Object.entries(BRANCHES).filter(([k]) => withAll || k !== 'ALL').map(([k, v]) => `<option value="${k}">${v}</option>`).join('');
const semOptions = placeholder => (placeholder ? `<option value="">${placeholder}</option>` : '')
  + [1, 2, 3, 4, 5, 6, 7, 8].map(n => `<option value="${n}">Semester ${n}</option>`).join('');
/* the server already resolves each listing's branches / semester (from its catalog book or its own fields) */
const bookOf = l => (l.bookId && books().find(b => b.id === l.bookId)) || null;
const metaOf = l => ({ branches: l.branches || [], sem: l.sem || 0 });

/* one listing card (used on Browse and on the Dashboard) */
const card = (l, tag) => {
  const st = l.sellerRating || { count: 0, avg: 0 }, m = metaOf(l);
  return `<a class="card" href="item.html?id=${l.id}">
    <div class="thumb">${CATS[l.category] || '📦'}<span class="badge ${l.type}">${l.type}</span>${l.status === 'SOLD' ? '<span class="badge sold">SOLD</span>' : ''}</div>
    <div class="cbody">${tag ? `<span class="tag">${esc(tag)}</span>` : ''}<h3>${esc(l.title)}</h3><div class="price">${priceText(l)}</div>
    <div class="meta">📍 ${esc(l.location)} · ${esc(l.sellerName)}${st.count ? ` · <span class="star">★</span> ${st.avg.toFixed(1)} (${st.count})` : ''}</div>
    ${m.sem || m.branches.length ? `<div class="meta">🎓 ${esc(branchText(m.branches))}${m.sem ? ' · Sem ' + m.sem : ''}</div>` : ''}
    <div class="meta">${ago(l.created)}</div></div></a>`;
};

/* ---------- ratings & reviews (one review per completed order) ---------- */
const stars = n => '★'.repeat(Math.round(n)) + '☆'.repeat(5 - Math.round(n));
const reviewCard = (r, o = {}) => `<div class="rev"><div class="rev-top"><span class="star">${stars(r.rating)}</span><b>${esc(r.buyerName)}</b>${r.demo ? '' : '<span class="vbadge">✔ Verified buyer</span>'}<span class="meta">${ago(r.created)}</span></div>
  ${r.text ? `<p>${esc(r.text)}</p>` : ''}<div class="meta">Item: ${esc(r.title)}${o.seller ? ' · Seller: ' + esc(r.sellerName) : ''}</div>
  ${o.del && me() && r.buyer === me().id ? `<button class="linkbtn" data-delrev="${r.id}" type="button">Delete my review</button>` : ''}</div>`;
const reviewForm = o => `<form class="rform" data-order="${o.id}" hidden>
  <div class="stars" data-v="0">${[1, 2, 3, 4, 5].map(i => `<button type="button" data-s="${i}" aria-label="${i} star">★</button>`).join('')}</div>
  <textarea rows="3" maxlength="400" placeholder="How was the seller and the item? (condition, punctuality, behaviour…)"></textarea>
  <div class="rbtns"><button class="btn sm">Submit review</button><button class="btn sm alt" type="button" data-cancel>Cancel</button></div></form>`;
function reviewBlock(o, tab) { // shown inside an order card on the Orders page
  const r = o.review;
  if (tab === 'sell') return r ? `<div class="mine-rev"><span class="star">${stars(r.rating)}</span> Buyer's review${r.text ? ': “' + esc(r.text) + '”' : ''}</div>` : '';
  if (r) return `<div class="mine-rev"><span class="star">${stars(r.rating)}</span> Your review${r.text ? ': “' + esc(r.text) + '”' : ''} <button class="linkbtn" data-delrev="${r.id}" type="button">Delete</button></div>`;
  if (o.status !== 'PAID') return '<div class="meta">⭐ You can rate the seller once the payment is confirmed.</div>';
  return `<button class="btn sm alt" data-rate="${o.id}" type="button">⭐ Rate seller</button>${reviewForm(o)}`;
}
function bindReviews(root, done) { // wires star pickers, submit, cancel and delete inside `root`; the server enforces who may review
  root.querySelectorAll('.stars').forEach(st => st.onclick = e => {
    const b = e.target.closest('button'); if (!b) return;
    st.dataset.v = b.dataset.s; st.querySelectorAll('button').forEach(x => x.classList.toggle('on', +x.dataset.s <= +b.dataset.s));
  });
  root.querySelectorAll('[data-rate]').forEach(b => b.onclick = () => { const f = root.querySelector(`.rform[data-order="${b.dataset.rate}"]`); if (f) f.hidden = !f.hidden; });
  root.querySelectorAll('[data-cancel]').forEach(b => b.onclick = () => { b.closest('.rform').hidden = true; });
  root.querySelectorAll('.rform').forEach(f => f.onsubmit = guard(async e => {
    e.preventDefault();
    const v = +f.querySelector('.stars').dataset.v;
    if (!v) return toast('Please tap a star rating first.');
    await api('/reviews', { method: 'POST', body: { orderId: f.dataset.order, rating: v, text: f.querySelector('textarea').value.trim() } });
    toast('Thanks for your review!'); await done();
  }));
  root.querySelectorAll('[data-delrev]').forEach(b => b.onclick = guard(async () => {
    if (!confirm('Delete your review?')) return;
    await api('/reviews/' + encodeURIComponent(b.dataset.delrev), { method: 'DELETE' }); await done();
  }));
}

/* password strength meter (used on the register and reset-password screens) */
function bindMeter(input, meter) {
  input.addEventListener('input', () => {
    const p = input.value, i = meter.querySelector('i');
    const s = [p.length >= 8, /[a-z]/.test(p) && /[A-Z]/.test(p), /\d/.test(p), /[^\w\s]/.test(p)].filter(Boolean).length;
    i.style.width = s * 25 + '%'; i.style.background = ['#dc2626', '#dc2626', '#f59e0b', '#84cc16', '#16a34a'][s];
  });
}
/* card helpers (demo checkout validates the format only; the number is never sent to the server) */
const luhn = n => { let s = 0, dbl = false; for (let i = n.length - 1; i >= 0; i--) { let x = +n[i]; if (dbl) { x *= 2; if (x > 9) x -= 9; } s += x; dbl = !dbl; } return s % 10 === 0; };
const cardBrand = n => /^4/.test(n) ? 'Visa' : /^(5[1-5]|2[2-7])/.test(n) ? 'Mastercard' : /^3[47]/.test(n) ? 'Amex' : /^(60|65|81|82|508)/.test(n) ? 'RuPay' : 'Card';
const loadRazorpay = () => window.Razorpay ? Promise.resolve() : new Promise((ok, no) => {
  const s = document.createElement('script'); s.src = 'https://checkout.razorpay.com/v1/checkout.js';
  s.onload = ok; s.onerror = () => no(new Error('Could not load Razorpay. Check your internet connection.')); document.head.append(s);
});

/* ---------- pages ---------- */
const pages = {
  async home() {
    const grid = $('#grid'), P = new URLSearchParams(location.search), bookId = P.get('book'), u = me();
    $('#cat').innerHTML = '<option value="">All categories</option>' + Object.keys(CATS).map(c => `<option>${c}</option>`).join('');
    $('#branch').innerHTML = branchOptions('All branches'); $('#sem').innerHTML = semOptions('All semesters');
    if (P.get('branch')) $('#branch').value = P.get('branch');
    if (P.get('sem')) $('#sem').value = P.get('sem');
    const bk = bookId && books().find(b => b.id === bookId);
    if (bk) $('#chip').innerHTML = `<span class="chip">📘 Showing copies of <b>${esc(bk.title)}</b> <a href="index.html">✕ Clear</a></span>`;
    if (u && (u.branch || u.sem)) { /* suggestions for the logged-in student */
      let rec = []; try { rec = await api('/recommendations?limit=4'); } catch { /* suggestions are optional */ }
      const q = `branch=${encodeURIComponent(u.branch || '')}&sem=${+u.sem || ''}`;
      $('#reco').innerHTML = `<div class="reco"><div class="reco-h"><h3>📌 Recommended for you <small>${esc(u.branch || '')}${u.sem ? ' · Semester ' + u.sem : ''}</small></h3><a href="dashboard.html">My Dashboard →</a></div>`
        + (rec.length ? `<div class="grid">${rec.map(l => card(l, l.tag)).join('')}</div>`
          : `<p class="meta">No matching books are listed yet. See the <a href="books.html?${q}">book catalog</a> or post a book you no longer need.</p>`) + '</div>';
    } else if (u) $('#reco').innerHTML = '<div class="note reco">🎓 Add your <b>branch &amp; semester</b> in your <a href="dashboard.html">Dashboard</a> to get textbook suggestions.</div>';

    let seq = 0, timer;
    async function draw() { // search + filters run on the server; `seq` drops answers that arrive out of order
      const my = ++seq, p = new URLSearchParams();
      [['q', $('#q').value.trim()], ['category', $('#cat').value], ['type', $('#type').value], ['max', $('#max').value], ['branch', $('#branch').value], ['sem', $('#sem').value], ['sort', $('#sort').value], ['book', bookId]]
        .forEach(([k, v]) => { if (v) p.set(k, v); });
      let r;
      try { r = await api('/listings?' + p); } catch (e) { if (my === seq) grid.innerHTML = `<div class="empty">⚠ ${esc(e.message)}</div>`; return; }
      if (my !== seq) return;
      $('#count').textContent = r.length + ' item' + (r.length === 1 ? '' : 's') + ' found';
      grid.innerHTML = r.length ? r.map(l => card(l)).join('') : '<div class="empty">No items match your search. Try changing the filters.</div>';
    }
    ['q', 'cat', 'branch', 'sem', 'type', 'max', 'sort'].forEach(i => $('#' + i).addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(draw, 200); }));
    await draw();
  },

  async item() {
    const id = new URLSearchParams(location.search).get('id'), box = $('#detail');
    const notFound = () => { box.innerHTML = '<div class="empty">Item not found. <a href="index.html">Back to browse</a></div>'; };
    if (!id) return notFound();
    let l;
    try { l = await api('/listings/' + encodeURIComponent(id)); } catch (e) { if (e.status === 404) return notFound(); throw e; }
    const u = me(), mine = u && u.id === l.seller, st = l.sellerRating, m = metaOf(l), bk = bookOf(l);
    const payable = ['SELL', 'RENT'].includes(l.type) && l.status !== 'SOLD' && l.price > 0;
    box.innerHTML = `<div class="big">${CATS[l.category] || '📦'}</div><div>
      <span class="badge ${l.type}" style="position:static;background:#eef0ff">${l.type}</span>
      ${l.status === 'SOLD' ? '<span class="badge sold" style="position:static;margin-left:6px">SOLD</span>' : ''}
      <h1>${esc(l.title)}</h1><div class="price" style="font-size:1.5rem">${priceText(l)}</div>
      <p style="margin:12px 0">${esc(l.desc || 'No description.')}</p>
      <div class="kv"><div><span>Category</span>${esc(l.category)}</div><div><span>Campus location</span>${esc(l.location)}</div>
      <div><span>Seller</span>${esc(l.sellerName)}</div>
      <div><span>Seller rating</span>${st.count ? `<a href="#reviews"><span class="star">★</span> ${st.avg.toFixed(1)} (${st.count} review${st.count > 1 ? 's' : ''})</a>` : 'No reviews yet'}</div>
      ${bk ? `<div><span>Book</span>${esc(bk.author)} · ${esc(bk.publisher)}</div>` : ''}
      ${m.sem || m.branches.length ? `<div><span>Suitable for</span>${esc(branchText(m.branches))}${m.sem ? ' · Semester ' + m.sem : ''}</div>` : ''}
      <div><span>Posted</span>${ago(l.created)}</div>
      ${l.type === 'RENT' ? `<div><span>Security deposit (refundable)</span>₹${l.deposit || 0}</div>` : ''}</div>
      <div style="display:flex;gap:10px;flex-wrap:wrap">
      ${mine ? `<button class="btn alt" id="sold">${l.status === 'SOLD' ? 'Mark available' : 'Mark as sold / rented'}</button><button class="btn danger" id="del">Delete</button>`
             : `${payable ? `<a class="btn pay" href="checkout.html?id=${l.id}">${l.type === 'RENT' ? '⏳ Rent now' : '🛒 Buy now'}</a>` : ''}<a class="btn ${payable ? 'alt' : ''}" href="chat.html?listing=${l.id}">💬 Chat with seller</a>`}
      <a class="btn alt" href="index.html">← Back</a></div></div>`;
    if (mine) {
      $('#sold').onclick = guard(async () => { await api('/listings/' + l.id, { method: 'PATCH', body: { status: l.status === 'SOLD' ? 'AVAILABLE' : 'SOLD' } }); location.reload(); });
      $('#del').onclick = guard(async () => { if (confirm('Delete this listing?')) { await api('/listings/' + l.id, { method: 'DELETE' }); location.href = 'index.html'; } });
    }

    /* seller reviews: rating summary, bar chart, review list, and a form for buyers with a paid order */
    async function drawReviews() {
      const rs = await api('/reviews?seller=' + l.seller), n = rs.length, avg = n ? rs.reduce((s, r) => s + r.rating, 0) / n : 0;
      const dist = [5, 4, 3, 2, 1].map(k => { const c = rs.filter(r => r.rating === k).length; return `<div class="bar"><span>${k}★</span><i><b style="width:${n ? c / n * 100 : 0}%"></b></i><span>${c}</span></div>`; }).join('');
      const pend = u ? (await api('/orders?role=buy')).filter(o => o.seller === l.seller && o.status === 'PAID' && !o.review) : [];
      $('#revPanel').innerHTML = `<h3 id="reviews" style="margin-bottom:10px">⭐ Student reviews for ${esc(l.sellerName)}</h3>`
        + pend.map(o => `<div class="note" style="margin-bottom:12px">You bought “${esc(o.title)}” from this seller. <button class="btn sm" data-rate="${o.id}" type="button">⭐ Write a review</button></div>${reviewForm(o)}`).join('')
        + (n ? `<div class="rsum"><div class="avg"><b>${avg.toFixed(1)}</b><div class="star">${stars(avg)}</div><small class="meta">${n} review${n > 1 ? 's' : ''}</small></div><div class="dist">${dist}</div></div><div class="revs">${rs.map(r => reviewCard(r, { del: true })).join('')}</div>`
          : '<p class="meta">No reviews yet. Buyers can rate the seller from their Orders page once a purchase is completed.</p>');
      bindReviews($('#revPanel'), () => location.reload());
    }
    await drawReviews();
  },

  async post() {
    if (!requireLogin()) return;
    $('#cat').innerHTML = Object.keys(CATS).map(c => `<option>${c}</option>`).join('');
    const toggle = () => { $('#rentBox').style.display = $('#type').value === 'RENT' ? 'grid' : 'none'; $('#priceBox').style.display = ['SELL', 'RENT'].includes($('#type').value) ? 'block' : 'none'; };
    /* Books / Notes can be linked to the catalog (title suggestions) or tagged with a branch + semester */
    $('#branch').innerHTML = branchOptions('Not specific', true); $('#sem').innerHTML = semOptions('Not specific');
    $('#booklist').innerHTML = books().map(b => `<option value="${esc(b.title)}">${esc(b.author)} · Sem ${b.sem}</option>`).join('');
    let linked = null;
    const acad = () => ['Books', 'Notes'].includes($('#cat').value);
    function syncBook() {
      const t = $('#title').value.trim().toLowerCase();
      linked = acad() ? books().find(b => b.title.toLowerCase() === t) || null : null;
      $('#bookInfo').textContent = linked ? `✔ Linked to the catalog: ${linked.author} · ${branchText(linked.branches)} · Semester ${linked.sem}`
        : acad() ? 'Tip: pick your book from the suggestions to link it to its branch & semester automatically.' : '';
      if (linked) { $('#branch').value = linked.branches.includes('ALL') ? 'ALL' : linked.branches[0]; $('#sem').value = linked.sem; }
      $('#branch').disabled = $('#sem').disabled = !!linked;
    }
    function acadToggle() {
      $('#acadBox').style.display = acad() ? 'grid' : 'none';
      if (acad()) $('#title').setAttribute('list', 'booklist'); else $('#title').removeAttribute('list');
      syncBook();
    }
    $('#cat').onchange = acadToggle; $('#title').addEventListener('input', syncBook);
    const pre = books().find(b => b.id === new URLSearchParams(location.search).get('book'));
    if (pre) { $('#cat').value = 'Books'; $('#title').value = pre.title; }
    acadToggle();
    $('#type').onchange = toggle; toggle();
    $('#form').onsubmit = guard(async e => {
      e.preventDefault();
      const t = $('#type').value;
      const body = { title: $('#title').value.trim(), category: $('#cat').value, type: t, desc: $('#desc').value.trim(), location: $('#loc').value.trim(),
        price: Math.round(Math.max(0, +$('#price').value || 0)) };
      if (t === 'RENT') { body.rentUnit = $('#unit').value; body.deposit = Math.round(Math.max(0, +$('#deposit').value || 0)); }
      if (acad()) { if (linked) body.bookId = linked.id; else { body.branch = $('#branch').value; body.sem = +$('#sem').value || 0; } }
      const l = await api('/listings', { method: 'POST', body });
      location.href = 'item.html?id=' + l.id;
    });
  },

  register() {
    const pw = $('#pw');
    $('#branch').innerHTML = branchOptions('Select branch'); $('#sem').innerHTML = semOptions('Select semester');
    $('#show').onclick = e => { e.preventDefault(); pw.type = pw.type === 'password' ? 'text' : 'password'; };
    bindMeter(pw, $('#meter'));
    $('#form').onsubmit = async e => {
      e.preventDefault();
      const msg = $('#msg'), p = pw.value;
      const fail = t => { msg.className = 'msg err'; msg.textContent = t; };
      if (p.length < 6) return fail('Password must be at least 6 characters.');
      if (p !== $('#pw2').value) return fail('Passwords do not match.');
      try {
        await api('/auth/register', { method: 'POST', body: { name: $('#name').value.trim(), email: $('#email').value.trim(), password: p,
          hostel: $('#hostel').value.trim(), branch: $('#branch').value, sem: +$('#sem').value || 0 } });
      } catch (err) { return fail(err.message); }
      msg.className = 'msg ok'; msg.textContent = 'Account created! Redirecting to login…';
      setTimeout(() => location.href = 'login.html', 1000);
    };
  },

  login() {
    if (me()) { const nx = new URLSearchParams(location.search).get('next'); location.replace(nx && /^[\w-]+\.html/.test(nx) ? nx : 'index.html'); return; }
    $('#show').onclick = e => { e.preventDefault(); const p = $('#pw'); p.type = p.type === 'password' ? 'text' : 'password'; };
    $('#form').onsubmit = async e => {
      e.preventDefault();
      try {
        const res = await api('/auth/login', { method: 'POST', body: { email: $('#email').value.trim(), password: $('#pw').value } });
        USER = res.user;
      } catch (err) { $('#msg').className = 'msg err'; $('#msg').textContent = err.message; return; }
      const next = new URLSearchParams(location.search).get('next');
      location.href = next && /^[\w-]+\.html/.test(next) ? next : 'index.html';
    };

    /* ---------- forgot password: email -> OTP -> new password (the server creates and checks the OTP) ---------- */
    let resetEmail = null, resetToken = null, timer = null;
    const note = (id, cls, t) => { const m = $('#' + id); m.className = 'msg ' + cls; m.textContent = t; };
    const show = v => {
      ['login', 'email', 'otp', 'new'].forEach(x => $('#v-' + x).hidden = x !== v);
      document.querySelectorAll('.msg').forEach(m => { m.className = 'msg'; m.textContent = ''; });
    };
    const cancel = () => { clearInterval(timer); resetEmail = resetToken = null; $('#demoOtp').hidden = true; show('login'); };

    function cooldown(sec) { // "Resend" is locked for a while so OTPs cannot be spammed (the server enforces this too)
      const b = $('#resend'); let s = sec;
      clearInterval(timer);
      const paint = () => { b.disabled = s > 0; b.textContent = s > 0 ? `Resend OTP in ${s}s` : 'Resend OTP'; };
      paint();
      timer = setInterval(() => { s--; paint(); if (s <= 0) clearInterval(timer); }, 1000);
    }
    async function sendOtp(email) {
      const res = await api('/auth/forgot', { method: 'POST', body: { email } });
      /* While developing, the server returns the OTP so it can be shown here. In production it is only e-mailed. */
      const box = $('#demoOtp'); box.hidden = !res.demoOtp;
      box.innerHTML = res.demoOtp ? `📧 <b>Demo mode</b> – no email server is connected, so your OTP is shown here: <b>${esc(res.demoOtp)}</b>` : '';
      cooldown(res.resendInSec || 30);
    }

    $('#forgot').onclick = e => { e.preventDefault(); show('email'); $('#fe').value = $('#email').value; $('#fe').focus(); };
    document.querySelectorAll('.back').forEach(a => a.onclick = e => { e.preventDefault(); cancel(); });

    $('#fEmail').onsubmit = async e => { // step 1: ask for the registered e-mail
      e.preventDefault();
      const email = $('#fe').value.trim().toLowerCase();
      try { await sendOtp(email); } catch (err) { return note('fmsg1', 'err', err.message); }
      resetEmail = email;
      $('#otpSub').textContent = `We sent a 6-digit OTP to ${email}. It is valid for 5 minutes.`;
      show('otp'); $('#otp').value = ''; $('#otp').focus();
    };

    $('#resend').onclick = async () => {
      if (!resetEmail) return;
      try { await sendOtp(resetEmail); $('#otp').value = ''; note('fmsg2', 'ok', 'A new OTP has been generated.'); } catch (err) { note('fmsg2', 'err', err.message); }
    };

    $('#fOtp').onsubmit = async e => { // step 2: the server checks the OTP (5 min expiry, max 5 wrong attempts)
      e.preventDefault();
      try {
        const r = await api('/auth/verify-otp', { method: 'POST', body: { email: resetEmail, otp: $('#otp').value.trim() } });
        resetToken = r.resetToken; clearInterval(timer);
      } catch (err) { return note('fmsg2', 'err', err.message); }
      show('new'); $('#np').focus();
    };

    $('#nshow').onclick = e => { e.preventDefault(); const p = $('#np'); p.type = p.type === 'password' ? 'text' : 'password'; };
    bindMeter($('#np'), $('#nmeter'));
    $('#fNew').onsubmit = async e => { // step 3: save the new password
      e.preventDefault();
      const p = $('#np').value;
      if (p.length < 6) return note('fmsg3', 'err', 'Password must be at least 6 characters.');
      if (p !== $('#np2').value) return note('fmsg3', 'err', 'Passwords do not match.');
      try { await api('/auth/reset-password', { method: 'POST', body: { email: resetEmail, resetToken, password: p } }); }
      catch (err) { if (/expired/i.test(err.message)) { cancel(); return note('msg', 'err', err.message); } return note('fmsg3', 'err', err.message); }
      const em = resetEmail; resetEmail = resetToken = null;
      $('#np').value = ''; $('#np2').value = '';
      show('login'); note('msg', 'ok', 'Password updated! Please login with your new password.');
      $('#email').value = em; $('#pw').value = ''; $('#pw').focus();
    };
  },

  async checkout() {
    if (!requireLogin()) return;
    const u = me(), root = $('#co');
    const stop = t => { root.innerHTML = `<div class="panel empty">${t} <a href="index.html">Back to browse</a></div>`; };
    const id = new URLSearchParams(location.search).get('id');
    if (!id) return stop('Item not found.');
    let l;
    try { l = await api('/listings/' + encodeURIComponent(id)); } catch (e) { return stop(e.status === 404 ? 'Item not found.' : esc(e.message)); }
    if (l.seller === u.id) return stop('You cannot pay for your own listing.');
    if (!['SELL', 'RENT'].includes(l.type) || !(+l.price > 0)) return stop('This listing has no payable amount. Use chat to arrange it with the seller.');
    if (l.status === 'SOLD') return stop('Sorry, this item has already been sold or rented.');

    const rent = l.type === 'RENT', unit = l.rentUnit || 'day', deposit = rent ? (+l.deposit || 0) : 0, online = !!CFG.razorpayKeyId;
    const METHODS = online
      ? [['online', '🌐', 'Pay online', 'UPI · Cards · Net Banking'], ['cod', '🤝', 'Pay on meetup', 'Cash / UPI at handover']]
      : [['upi', '📱', 'UPI', 'GPay · PhonePe · Paytm'], ['card', '💳', 'Card', 'Debit / Credit'], ['nb', '🏦', 'Net Banking', 'All major banks'], ['cod', '🤝', 'Pay on meetup', 'Cash / UPI at handover']];
    const BANKS = ['State Bank of India', 'HDFC Bank', 'ICICI Bank', 'Axis Bank', 'Punjab National Bank', 'Kotak Mahindra Bank', 'Bank of Baroda', 'Canara Bank'];
    let method = METHODS[0][0], qty = 1;
    const total = () => (+l.price) * (rent ? qty : 1) + deposit; // display only - the server recomputes the real amount

    root.innerHTML = `<div class="co">
      <div class="panel">
        <h2>Choose payment method</h2>
        <p class="meta" style="margin-bottom:14px">${online ? 'Secure checkout powered by Razorpay.' : 'Demo checkout – no real money is charged.'}</p>
        <div class="methods" id="methods">${METHODS.map(([v, ic, n, s], i) => `<label class="m"><input type="radio" name="m" value="${v}" ${i ? '' : 'checked'}><span class="ic">${ic}</span><span><b>${n}</b><small>${s}</small></span></label>`).join('')}</div>
        <div id="msg" class="msg"></div>
        <form id="payForm" novalidate>
          <div class="mp" id="p-upi" hidden><div class="field"><label>UPI ID</label><input id="upi" placeholder="yourname@okaxis" autocomplete="off"><div class="hint">Example: rahul@oksbi or 9876543210@ybl</div></div></div>
          <div class="mp" id="p-card" hidden>
            <div class="field"><label>Card number</label><input id="cn" inputmode="numeric" placeholder="1234 5678 9012 3456" autocomplete="off"></div>
            <div class="field"><label>Name on card</label><input id="cname" autocomplete="off"></div>
            <div class="row2"><div class="field"><label>Expiry (MM/YY)</label><input id="cexp" inputmode="numeric" placeholder="MM/YY" autocomplete="off"></div><div class="field"><label>CVV</label><input id="ccvv" type="password" inputmode="numeric" placeholder="•••" autocomplete="off"></div></div>
            <div class="hint">Test cards: <b>4111 1111 1111 1111</b> succeeds · <b>4000 0000 0000 0002</b> is declined. Any future expiry and any CVV.</div>
          </div>
          <div class="mp" id="p-nb" hidden><div class="field"><label>Select your bank</label><select id="bank"><option value="">Choose bank…</option>${BANKS.map(b => `<option>${b}</option>`).join('')}</select></div></div>
          <div class="mp" id="p-online" hidden><p class="note">A secure Razorpay window will open where you can pay with UPI, card, net banking or wallet.</p></div>
          <div class="mp" id="p-cod" hidden><p class="note">No online payment now. Meet <b>${esc(l.sellerName)}</b> at <b>${esc(l.location)}</b> and pay in cash or UPI when you receive the item. The seller confirms the payment in their Orders page.</p></div>
          <button class="btn full pay" id="payBtn"></button>
        </form>
        <p class="secure">🔒 ${online ? 'Payments are handled by Razorpay and verified on our server.' : 'Demo gateway only. Card details are never saved or sent.'}</p>
      </div>
      <aside class="panel">
        <h3>Order summary</h3>
        <div class="sum-item"><span class="sum-ic">${CATS[l.category] || '📦'}</span><div><b>${esc(l.title)}</b><div class="meta">Seller: ${esc(l.sellerName)} · 📍 ${esc(l.location)}</div></div></div>
        ${rent ? `<div class="field" style="margin-top:14px"><label>Rental duration (${unit}s)</label><input id="qty" type="number" min="1" max="30" value="1"></div>` : ''}
        <div class="kv" id="sum"></div>
      </aside></div>`;

    const row = (a, b) => `<div><span>${a}</span>${b}</div>`;
    function drawSum() {
      $('#sum').innerHTML = (rent ? row(`Rent ${rupee(l.price)} × ${qty} ${unit}${qty > 1 ? 's' : ''}`, rupee(l.price * qty)) + row('Refundable deposit', rupee(deposit)) : row('Item price', rupee(l.price)))
        + `<div class="total"><span>Total payable</span><b>${rupee(total())}</b></div>`;
      $('#payBtn').textContent = method === 'cod' ? `Place order · pay ${rupee(total())} on meetup` : `Pay ${rupee(total())}`;
    }
    function pick(v) {
      method = v;
      document.querySelectorAll('.mp').forEach(p => p.hidden = p.id !== 'p-' + v);
      document.querySelectorAll('.m').forEach(m => m.classList.toggle('on', m.querySelector('input').value === v));
      $('#msg').className = 'msg'; drawSum();
    }
    $('#methods').addEventListener('change', e => pick(e.target.value));
    if (rent) {
      $('#qty').addEventListener('input', e => { qty = Math.min(30, Math.max(1, parseInt(e.target.value) || 1)); drawSum(); });
      $('#qty').addEventListener('change', e => { e.target.value = qty; });
    }
    $('#cn').addEventListener('input', e => { e.target.value = e.target.value.replace(/\D/g, '').slice(0, 19).replace(/(.{4})/g, '$1 ').trim(); });
    $('#cexp').addEventListener('input', e => { const v = e.target.value.replace(/\D/g, '').slice(0, 4); e.target.value = v.length > 2 ? v.slice(0, 2) + '/' + v.slice(2) : v; });
    $('#ccvv').addEventListener('input', e => { e.target.value = e.target.value.replace(/\D/g, '').slice(0, 4); });

    const err = t => { $('#msg').className = 'msg err'; $('#msg').textContent = t; };
    const busy = (on, t) => { const b = $('#payBtn'); b.disabled = on; if (on) b.textContent = t; else drawSum(); };

    function validate() { // returns an error message, or null when the details look fine
      if (method === 'upi' && !/^[\w.\-]{2,}@[a-zA-Z]{2,}$/.test($('#upi').value.trim())) return 'Enter a valid UPI ID, e.g. name@okaxis.';
      if (method === 'card') {
        const n = $('#cn').value.replace(/\s/g, ''), ex = $('#cexp').value.match(/^(\d{2})\/(\d{2})$/);
        if (n.length < 13 || !luhn(n)) return 'Enter a valid card number.';
        if (!$('#cname').value.trim()) return 'Enter the name on the card.';
        if (!ex || +ex[1] < 1 || +ex[1] > 12 || new Date(2000 + +ex[2], +ex[1], 1) <= new Date()) return 'Enter a valid, unexpired expiry date (MM/YY).';
        if (!/^\d{3,4}$/.test($('#ccvv').value)) return 'Enter the 3 or 4 digit CVV.';
      }
      if (method === 'nb' && !$('#bank').value) return 'Please select your bank.';
      return null;
    }
    function details() { // what we send with the order: only a label, never the full card number or CVV
      if (method === 'upi') return { label: 'UPI · ' + $('#upi').value.trim() };
      if (method === 'card') { const n = $('#cn').value.replace(/\s/g, ''); return { label: `${cardBrand(n)} ···· ${n.slice(-4)}`, declined: n.endsWith('0002') }; }
      if (method === 'nb') return { label: 'Net Banking · ' + $('#bank').value };
      return { label: 'Pay on meetup' };
    }

    async function finish(payload) { // the server checks availability, computes the amount and creates the order
      const o = await api('/orders', { method: 'POST', body: { listingId: l.id, qty: rent ? qty : 1, ...payload } });
      receipt(o);
    }
    function receipt(o) {
      const paid = o.status === 'PAID';
      root.innerHTML = `<div class="panel receipt"><div class="tick ${paid ? '' : 'wait'}">${paid ? '✔' : '🤝'}</div>
        <h2>${paid ? 'Payment successful' : 'Order placed'}</h2>
        <p class="meta">${paid ? 'Your payment has been received.' : 'Pay the seller when you meet to collect the item.'}</p>
        <div class="kv">
          <div><span>Order / Transaction ID</span><b>${esc(o.ref)}</b></div>
          <div><span>Item</span>${esc(o.title)}</div>
          ${o.type === 'RENT' ? `<div><span>Rental</span>${o.qty} ${o.unit}${o.qty > 1 ? 's' : ''} × ${rupee(o.price)} + ${rupee(o.deposit)} deposit</div>` : ''}
          <div><span>Amount ${paid ? 'paid' : 'to pay'}</span><b>${rupee(o.amount)}</b></div>
          <div><span>Payment method</span>${esc(o.method)}</div>
          <div><span>Seller</span>${esc(o.sellerName)}</div>
          <div><span>Meet at</span>${esc(o.location)}</div>
          <div><span>Date</span>${fmtDate(o.created)}</div>
        </div>
        <div class="actions"><a class="btn" href="orders.html">View my orders</a><a class="btn alt" href="chat.html?listing=${l.id}">💬 Chat with seller</a><button class="btn alt" id="print" type="button">🖨 Print receipt</button></div></div>`;
      $('#print').onclick = () => window.print();
    }

    $('#payForm').onsubmit = async e => {
      e.preventDefault();
      $('#msg').className = 'msg';
      const bad = validate(); if (bad) return err(bad);
      const d = details();
      try {
        if (method === 'cod') return await finish({ method: 'cod' });
        busy(true, '⏳ Processing payment…');
        if (online) { // real gateway: the server creates the Razorpay order and later verifies the payment signature
          const z = await api('/payments/razorpay/order', { method: 'POST', body: { listingId: l.id, qty: rent ? qty : 1 } });
          await loadRazorpay();
          const rz = new Razorpay({ key: z.keyId, amount: z.amount, currency: z.currency, order_id: z.orderId, name: 'Campus Exchange', description: l.title,
            prefill: { name: u.name, email: u.email }, theme: { color: '#4f46e5' },
            handler: r => finish({ method: 'online', razorpay: { orderId: r.razorpay_order_id, paymentId: r.razorpay_payment_id, signature: r.razorpay_signature } })
              .catch(x => { busy(false); err(x.message); }),
            modal: { ondismiss: () => { busy(false); err('Payment cancelled.'); } } });
          rz.on('payment.failed', r => { busy(false); err((r.error && r.error.description) || 'Payment failed.'); });
          rz.open();
          return;
        }
        await new Promise(ok => setTimeout(ok, 1800)); // demo gateway: pretend the bank takes ~2 seconds
        if (d.declined) { busy(false); return err('Payment declined by the bank. Try another card or payment method.'); }
        await finish({ method, label: d.label });
      } catch (x) { busy(false); err(x.message); }
    };

    pick(method);
  },

  async orders() {
    if (!requireLogin()) return;
    let tab = 'buy';
    const list = $('#olist'), tabs = document.querySelectorAll('.tab');
    const label = { PAID: 'Paid', PAY_ON_MEETUP: 'Pay on meetup' };
    async function draw() {
      tabs.forEach(t => t.classList.toggle('on', t.dataset.tab === tab));
      let all;
      try { all = await api('/orders?role=' + tab); } catch (e) { list.innerHTML = `<div class="empty">⚠ ${esc(e.message)}</div>`; return; }
      list.innerHTML = all.length ? all.map(o => `<div class="order">
          <div class="o-top">${o.listingId ? `<a href="item.html?id=${o.listingId}"><b>${esc(o.title)}</b></a>` : `<b>${esc(o.title)}</b>`}<span class="pill ${o.status}">${label[o.status] || esc(o.status)}</span></div>
          <div class="o-mid"><span class="price">${rupee(o.amount)}</span><span class="meta">${o.type === 'RENT' ? `Rental · ${o.qty} ${o.unit}${o.qty > 1 ? 's' : ''} + deposit` : 'Purchase'} · ${esc(o.method)}</span></div>
          <div class="meta">${tab === 'buy' ? 'Seller: ' + esc(o.sellerName) : 'Buyer: ' + esc(o.buyerName)} · 📍 ${esc(o.location)} · ${fmtDate(o.created)}</div>
          <div class="meta">Ref: ${esc(o.ref)}</div>
          ${reviewBlock(o, tab)}
          ${tab === 'sell' && o.status === 'PAY_ON_MEETUP' ? `<button class="btn sm pay" data-id="${o.id}" type="button">✔ Confirm payment received</button>` : ''}
        </div>`).join('')
        : `<div class="empty">${tab === 'buy' ? 'You have not bought or rented anything yet.' : 'No orders for your listings yet.'}</div>`;
      bindReviews(list, draw);
      list.querySelectorAll('[data-id]').forEach(b => b.onclick = guard(async () => {
        await api('/orders/' + encodeURIComponent(b.dataset.id) + '/confirm', { method: 'POST' }); toast('Payment marked as received'); await draw();
      }));
    }
    tabs.forEach(t => t.onclick = () => { tab = t.dataset.tab; draw(); });
    await draw();
  },

  /* ---------- Book catalog: textbooks arranged by semester, filtered by branch ---------- */
  async catalog() {
    const u = me(), P = new URLSearchParams(location.search), grid = $('#cgrid');
    $('#cbranch').innerHTML = branchOptions('All branches'); $('#csem').innerHTML = semOptions('All semesters');
    $('#fbranch').innerHTML = branchOptions('Select branch', true); $('#fsem').innerHTML = semOptions('Select semester');
    $('#cbranch').value = P.get('branch') || ''; $('#csem').value = P.get('sem') || '';

    const bookCard = b => `<div class="card"><div class="thumb">📘<span class="badge">Sem ${b.sem}</span></div><div class="cbody">
        <h3>${esc(b.title)}</h3><div class="meta">✍ ${esc(b.author)}</div><div class="meta">${esc(b.publisher || '')}</div>
        <div class="meta">📖 ${esc(b.subject)}</div><div class="meta">🎓 ${esc(branchText(b.branches))}</div>
        <div class="avail ${b.copies ? 'yes' : ''}">${b.copies ? `${b.copies} cop${b.copies > 1 ? 'ies' : 'y'} available${b.fromPrice ? ' · from ' + rupee(b.fromPrice) : ''}` : 'No copies listed yet'}</div>
        <div class="bk-actions"><a class="btn sm ${b.copies ? '' : 'alt'}" href="index.html?book=${b.id}">Find copies</a><a class="btn sm alt" href="post.html?book=${b.id}">Sell yours</a>
        ${b.custom && u && b.addedBy === u.id ? `<button class="linkbtn" data-delbook="${b.id}" type="button">Remove</button>` : ''}</div></div></div>`;
    function draw() {
      const q = $('#cq').value.toLowerCase().trim(), br = $('#cbranch').value, sm = +$('#csem').value;
      const r = books().filter(b => (!q || (b.title + ' ' + b.author + ' ' + b.subject + ' ' + (b.publisher || '')).toLowerCase().includes(q))
        && (!br || b.branches.includes('ALL') || b.branches.includes(br)) && (!sm || b.sem === sm)).sort((a, b) => a.sem - b.sem || a.title.localeCompare(b.title));
      $('#ccount').textContent = r.length + ' book' + (r.length === 1 ? '' : 's') + ' in the catalog';
      grid.innerHTML = r.length ? [...new Set(r.map(b => b.sem))].map(s => `<h3 class="semh">Semester ${s}</h3><div class="grid">${r.filter(b => b.sem === s).map(bookCard).join('')}</div>`).join('')
        : '<div class="empty">No books found. Try another filter, or add the book using the form below.</div>';
      grid.querySelectorAll('[data-delbook]').forEach(b => b.onclick = guard(async () => {
        if (!confirm('Remove this book from the catalog?')) return;
        await api('/books/' + encodeURIComponent(b.dataset.delbook), { method: 'DELETE' }); await refreshBooks(); draw();
      }));
    }
    ['cq', 'cbranch', 'csem'].forEach(i => $('#' + i).addEventListener('input', draw));
    $('#mine').onclick = () => {
      if (!u || !(u.branch || u.sem)) return toast('Set your branch & semester in the Dashboard first.');
      $('#cbranch').value = u.branch || ''; $('#csem').value = u.sem || ''; draw();
    };
    $('#bform').onsubmit = guard(async e => { // students can add a missing book (stored with the catalog)
      e.preventDefault();
      if (!u) return toast('Please login to add a book.');
      await api('/books', { method: 'POST', body: { title: $('#ftitle').value.trim(), author: $('#fauthor').value.trim(), publisher: $('#fpub').value.trim(),
        subject: $('#fsub').value.trim(), branch: $('#fbranch').value, sem: +$('#fsem').value } });
      e.target.reset(); await refreshBooks(); toast('Book added to the catalog'); draw();
    });
    draw();
  },

  /* ---------- My Dashboard ---------- */
  async dashboard() {
    if (!requireLogin()) return;
    const root = $('#dash');
    async function draw() {
      const D = await api('/dashboard'), u = me();
      const { mine, sales, buys, received: got, given: gave, rating: st, recommended: rec } = D;
      const earned = sales.filter(o => o.status === 'PAID').reduce((s, o) => s + o.price * o.qty, 0);
      const toConfirm = sales.filter(o => o.status === 'PAY_ON_MEETUP');
      const toRate = buys.filter(o => o.status === 'PAID' && !o.review);
      const ini = u.name.split(/\s+/).map(w => w[0]).join('').slice(0, 2).toUpperCase();
      const q = `branch=${encodeURIComponent(u.branch || '')}&sem=${+u.sem || ''}`;
      root.innerHTML = `
        <div class="panel dhead"><div class="avatar">${esc(ini)}</div><div><h2>${esc(u.name)}</h2><p class="meta">${esc(u.email)}</p></div>
          <form id="pform" class="pform">
            <div class="field"><label>Branch</label><select id="pbranch"></select></div>
            <div class="field"><label>Semester</label><select id="psem"></select></div>
            <div class="field"><label>Hostel / area</label><input id="phostel" maxlength="40"></div>
            <button class="btn">Save profile</button></form></div>
        ${u.branch && u.sem ? '' : '<div class="note" style="margin-bottom:16px">🎓 Choose your branch and semester above to get textbook suggestions.</div>'}
        <div class="stats">
          <div class="stat"><small>📦 Active listings</small><b>${mine.filter(l => l.status !== 'SOLD').length}</b></div>
          <div class="stat"><small>✅ Sold / rented out</small><b>${mine.filter(l => l.status === 'SOLD').length}</b></div>
          <div class="stat"><small>💰 Earned (confirmed)</small><b>${rupee(earned)}</b></div>
          <div class="stat"><small>🛍 My purchases</small><b>${buys.length}</b></div>
          <div class="stat"><small>⭐ Seller rating</small><b>${st.count ? st.avg.toFixed(1) + ' / 5' : '—'}</b>${st.count ? `<small>${st.count} review${st.count > 1 ? 's' : ''}</small>` : ''}</div>
          <div class="stat"><small>🔔 To do</small><b>${toConfirm.length + toRate.length}</b></div></div>
        ${toConfirm.length || toRate.length ? `<div class="panel"><h3>🔔 Needs your attention</h3>
          ${toConfirm.map(o => `<div class="drow"><div><b>${esc(o.title)}</b><div class="meta">${esc(o.buyerName)} pays ${rupee(o.amount)} on meetup at ${esc(o.location)}</div></div><button class="btn sm pay" data-confirm="${o.id}" type="button">✔ Confirm payment received</button></div>`).join('')}
          ${toRate.map(o => `<div class="drow"><div><b>${esc(o.title)}</b><div class="meta">How was ${esc(o.sellerName)}? Leave a review.</div></div><button class="btn sm alt" data-rate="${o.id}" type="button">⭐ Rate seller</button></div>${reviewForm(o)}`).join('')}</div>` : ''}
        <div class="panel"><div class="reco-h"><h3>📌 Suggested books <small>${esc(u.branch || '')}${u.sem ? ' · Semester ' + u.sem : ''}</small></h3><a href="books.html?${q}">Open book catalog →</a></div>
          ${rec.length ? `<div class="grid">${rec.map(l => card(l, l.tag)).join('')}</div>`
            : `<p class="meta">${u.branch || u.sem ? 'No matching listings right now. Check the catalog and come back later.' : 'Save your branch and semester to see suggestions here.'}</p>`}</div>
        <div class="panel"><div class="reco-h"><h3>📦 My listings (${mine.length})</h3><a class="btn sm" href="post.html">+ Post item</a></div>
          ${mine.length ? mine.map(l => `<div class="drow"><div><a href="item.html?id=${l.id}"><b>${esc(l.title)}</b></a><div class="meta">${l.type} · ${priceText(l)} · ${l.status === 'SOLD' ? 'Sold / rented' : 'Available'} · ${ago(l.created)}</div></div>
            <div class="dact"><button class="btn sm alt" data-toggle="${l.id}" data-status="${l.status}" type="button">${l.status === 'SOLD' ? 'Mark available' : 'Mark sold'}</button><button class="btn sm danger" data-del="${l.id}" type="button">Delete</button></div></div>`).join('')
            : '<p class="meta">You have not posted anything yet.</p>'}</div>
        <div class="two">
          <div class="panel"><h3>⭐ Reviews I received (${got.length})</h3>${got.length ? got.map(r => reviewCard(r)).join('') : '<p class="meta">No reviews yet. They appear after buyers rate you.</p>'}</div>
          <div class="panel"><h3>✍ Reviews I wrote (${gave.length})</h3>${gave.length ? gave.map(r => reviewCard(r, { seller: true, del: true })).join('') : '<p class="meta">Rate sellers from your Orders page after a purchase.</p>'}</div></div>`;

      $('#pbranch').innerHTML = branchOptions('Select branch'); $('#pbranch').value = u.branch || '';
      $('#psem').innerHTML = semOptions('Select semester'); $('#psem').value = u.sem || '';
      $('#phostel').value = u.hostel || '';
      $('#pform').onsubmit = guard(async e => {
        e.preventDefault();
        USER = (await api('/users/me', { method: 'PATCH', body: { branch: $('#pbranch').value, sem: +$('#psem').value || 0, hostel: $('#phostel').value.trim() } })).user;
        toast('Profile saved'); await draw();
      });
      root.querySelectorAll('[data-confirm]').forEach(b => b.onclick = guard(async () => {
        await api('/orders/' + encodeURIComponent(b.dataset.confirm) + '/confirm', { method: 'POST' }); toast('Payment marked as received'); await draw();
      }));
      root.querySelectorAll('[data-toggle]').forEach(b => b.onclick = guard(async () => {
        await api('/listings/' + encodeURIComponent(b.dataset.toggle), { method: 'PATCH', body: { status: b.dataset.status === 'SOLD' ? 'AVAILABLE' : 'SOLD' } }); await draw();
      }));
      root.querySelectorAll('[data-del]').forEach(b => b.onclick = guard(async () => {
        if (confirm('Delete this listing?')) { await api('/listings/' + encodeURIComponent(b.dataset.del), { method: 'DELETE' }); await draw(); }
      }));
      bindReviews(root, draw);
    }
    await draw();
  },

  async chat() {
    if (!requireLogin()) return;
    const u = me(); let active = null, convs = [], thread = { chat: null, messages: [] }, busy = false;
    const lid = new URLSearchParams(location.search).get('listing');
    if (lid) { // open (or create) a conversation about a listing
      try { active = (await api('/chats', { method: 'POST', body: { listingId: lid } })).id; } catch (e) { toast(e.message); }
    }
    const other = c => c.buyer === u.id ? c.sellerName : c.buyerName;
    function drawList() {
      $('#convs').innerHTML = '<h3>Conversations</h3>' + (convs.length ? convs.map(c => `<div class="conv ${c.id === active ? 'on' : ''}" data-id="${c.id}"><b>${esc(other(c))}</b><small>${esc(c.title)} · ${esc(c.last ? c.last.text : 'No messages yet')}</small></div>`).join('')
        : '<div class="noconv">No chats yet.<br>Open an item and tap “Chat with seller”.</div>');
      document.querySelectorAll('.conv').forEach(el => el.onclick = guard(async () => { await openThread(el.dataset.id); }));
    }
    async function openThread(id) { thread = await api('/chats/' + encodeURIComponent(id)); active = id; drawList(); drawThread(true); }
    function drawThread(force) {
      const c = thread.chat, box = $('#thread');
      if (!active || !c) { box.innerHTML = '<div class="noconv">Select a conversation to start chatting.</div>'; return; }
      const sig = c.id + ':' + (thread.messages.at(-1)?.id || 0);
      if (!force && box.dataset.sig === sig) return;
      box.dataset.sig = sig;
      const draft = $('#txt') ? $('#txt').value : '';
      box.innerHTML = `<div class="thead">${esc(other(c))}<small>About: ${c.listingId ? `<a href="item.html?id=${c.listingId}">${esc(c.title)}</a>` : esc(c.title)} · you are the ${c.buyer === u.id ? 'buyer' : 'seller'}</small></div>
        <div class="msgs" id="msgs">${thread.messages.length ? thread.messages.map(m => `<div class="bub ${m.from === u.id ? 'me' : 'them'}">${esc(m.text)}<small>${fmtTime(m.t)}</small></div>`).join('') : '<div class="noconv">Say hello 👋 and ask about the item.</div>'}</div>
        <form class="sendbar" id="send"><input id="txt" placeholder="Type a message…" autocomplete="off" required maxlength="1000"><button class="btn">Send</button></form>`;
      const m = $('#msgs'); m.scrollTop = m.scrollHeight;
      $('#txt').value = draft;
      $('#send').onsubmit = guard(async e => {
        e.preventDefault();
        const t = $('#txt').value.trim(); if (!t) return;
        $('#txt').value = '';
        await api(`/chats/${encodeURIComponent(c.id)}/messages`, { method: 'POST', body: { text: t } });
        await refresh();
        if (c.demo) setTimeout(() => refresh().catch(() => {}), 1500); // the demo seller answers after about a second
      });
    }
    async function refresh() { // picks up new messages (and chats) from other accounts / tabs
      if (busy) return; busy = true;
      try {
        const after = thread.messages.at(-1)?.id || 0;
        const [list, more] = await Promise.all([api('/chats'), active && thread.chat ? api(`/chats/${encodeURIComponent(active)}/messages?after=${after}`) : null]);
        convs = list;
        if (more && more.messages.length) thread.messages.push(...more.messages);
        drawList(); drawThread();
      } finally { busy = false; }
    }
    convs = await api('/chats');
    if (!active && convs.length) active = convs[0].id;
    if (active) await openThread(active); else { drawList(); drawThread(true); }
    setInterval(() => { if (!document.hidden) refresh().catch(() => {}); }, 2500);
  }
};

document.addEventListener('DOMContentLoaded', async () => {
  const page = document.body.dataset.page;
  try {
    await findServer();
    const [cfg, who, bks] = await Promise.all([api('/config'), api('/auth/me'), api('/books')]);
    CFG = cfg; USER = who.user; BOOKS = bks;
  } catch (e) { layout(page); return fatal(e); }
  layout(page);
  try { if (pages[page]) await pages[page](); } catch (e) { fatal(e); }
});


/* ============ UI polish: slim page banner (same graphic as the home hero) ============ */
(function () {
  const T = {
    catalog:   ['Book catalog', 'Textbooks by semester and branch. See who is selling a copy, or list yours.'],
    post:      ['Post an item', 'Sell, rent, swap or give away. Students on your campus will see it right away.'],
    chat:      ['Messages', 'Talk to buyers and sellers on your campus.'],
    orders:    ['My orders', 'Your purchases, rentals and sales in one place.'],
    dashboard: ['My dashboard', 'Your profile, listings and reviews.']
  };
  const t = T[document.body.dataset.page];
  const main = document.querySelector('main');
  if (!t || !main) return;
  const b = document.createElement('section');
  b.className = 'pbanner';
  b.innerHTML = '<h1></h1><p></p>';
  b.firstChild.textContent = t[0];
  b.lastChild.textContent = t[1];
  main.prepend(b);
  document.body.classList.add('has-banner');
})();
