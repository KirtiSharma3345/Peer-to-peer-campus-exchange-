/* ============================================================
   Book catalog – the "database" of textbooks for Campus Exchange.

   app.js copies BOOKS_SEED into localStorage (key: cx_books) the first time the
   site opens, and again whenever BOOKS_VERSION is increased. Books that students
   add from the Books page (custom: true) are kept when the catalog is reloaded.

   branches : ['ALL'] = common first-year book, otherwise a list of branch codes
   sem      : the usual B.Tech semester for that subject – change it to match
              your own university syllabus (this is a typical scheme, not official)

   Keep this file in the same folder as app.js and load it BEFORE app.js.
   ============================================================ */
const BRANCHES = {
  ALL: 'First Year (Common)',
  CSE: 'Computer Science (CSE)',
  AI: 'AI & Machine Learning (AI/ML)',
  ECE: 'Electronics & Communication (ECE)',
  EE: 'Electrical (EE)',
  ME: 'Mechanical (ME)',
  CE: 'Civil (CE)'
};

const BOOKS_VERSION = 1; // increase this number after editing BOOKS_SEED so browsers reload it

const _b = (title, author, publisher, subject, sem, branches) => ({
  id: title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, ''),
  title, author, publisher, subject, sem, branches
});
const _ALL = ['ALL'], _CS = ['CSE', 'AI'];

const BOOKS_SEED = [
  /* ---------- First year (all branches) ---------- */
  _b('Concepts of Physics', 'H.C. Verma', 'Bharati Bhawan', 'Engineering Physics', 1, _ALL),
  _b('Engineering Physics', 'H.K. Malik & A.K. Singh', 'McGraw Hill', 'Engineering Physics', 1, _ALL),
  _b('Engineering Chemistry', 'P.C. Jain & Monica Jain', 'Dhanpat Rai', 'Engineering Chemistry', 1, _ALL),
  _b('Higher Engineering Mathematics', 'B.S. Grewal', 'Khanna Publishers', 'Engineering Mathematics', 1, _ALL),
  _b('Advanced Engineering Mathematics', 'Erwin Kreyszig', 'Wiley', 'Engineering Mathematics', 2, _ALL),
  _b('Programming in ANSI C', 'E. Balagurusamy', 'McGraw Hill', 'Programming for Problem Solving', 1, _ALL),
  _b('Let Us C', 'Yashavant Kanetkar', 'BPB Publications', 'Programming for Problem Solving', 1, _ALL),
  _b('Basic Electrical Engineering', 'D.P. Kothari & I.J. Nagrath', 'McGraw Hill', 'Basic Electrical Engineering', 2, _ALL),
  _b('Engineering Drawing', 'N.D. Bhatt', 'Charotar Publishing', 'Engineering Graphics', 2, _ALL),
  _b('Environmental Studies', 'Erach Bharucha', 'Universities Press', 'Environment & Ecology', 2, _ALL),
  _b('Communication Skills', 'Sanjay Kumar & Pushp Lata', 'Oxford University Press', 'Professional Communication', 2, _ALL),

  /* ---------- CSE + AI/ML (shared core) ---------- */
  _b('Data Structures Using C', 'Reema Thareja', 'Oxford University Press', 'Data Structures', 3, _CS),
  _b('Discrete Mathematics and Its Applications', 'Kenneth H. Rosen', 'McGraw Hill', 'Discrete Structures', 3, _CS),
  _b('Computer System Architecture', 'M. Morris Mano', 'Pearson', 'Computer Organization', 3, _CS),
  _b('Object-Oriented Programming with C++', 'E. Balagurusamy', 'McGraw Hill', 'Object Oriented Programming', 3, _CS),
  _b('Python Programming: Using Problem Solving Approach', 'Reema Thareja', 'Oxford University Press', 'Python Programming', 3, _CS),
  _b('Introduction to Algorithms', 'T.H. Cormen, C.E. Leiserson, R.L. Rivest & C. Stein', 'MIT Press / PHI', 'Design & Analysis of Algorithms', 4, _CS),
  _b('Operating System Concepts', 'A. Silberschatz, P.B. Galvin & G. Gagne', 'Wiley', 'Operating Systems', 4, _CS),
  _b('Introduction to Automata Theory, Languages and Computation', 'J.E. Hopcroft, R. Motwani & J.D. Ullman', 'Pearson', 'Theory of Computation', 4, _CS),
  _b('Database System Concepts', 'A. Silberschatz, H.F. Korth & S. Sudarshan', 'McGraw Hill', 'Database Management Systems', 4, _CS),
  _b('Compilers: Principles, Techniques and Tools', 'A.V. Aho, M.S. Lam, R. Sethi & J.D. Ullman', 'Pearson', 'Compiler Design', 5, _CS),
  _b('Computer Networks', 'Andrew S. Tanenbaum', 'Pearson', 'Computer Networks', 5, _CS),
  _b('Data Communications and Networking', 'Behrouz A. Forouzan', 'McGraw Hill', 'Computer Networks', 5, _CS),
  _b("Software Engineering: A Practitioner's Approach", 'Roger S. Pressman', 'McGraw Hill', 'Software Engineering', 5, _CS),
  _b('Artificial Intelligence: A Modern Approach', 'Stuart Russell & Peter Norvig', 'Pearson', 'Artificial Intelligence', 6, _CS),
  _b('Cryptography and Network Security', 'William Stallings', 'Pearson', 'Network Security', 6, _CS),
  _b('Computer Graphics', 'Donald Hearn & M. Pauline Baker', 'Pearson', 'Computer Graphics', 6, ['CSE']),
  _b('Data Mining: Concepts and Techniques', 'Jiawei Han, Micheline Kamber & Jian Pei', 'Morgan Kaufmann', 'Data Mining', 7, _CS),
  _b('Mastering Cloud Computing', 'R. Buyya, C. Vecchiola & S.T. Selvi', 'McGraw Hill', 'Cloud Computing', 7, ['CSE']),

  /* ---------- AI & Machine Learning only ---------- */
  _b('Introduction to Linear Algebra', 'Gilbert Strang', 'Wellesley-Cambridge Press', 'Linear Algebra for ML', 3, ['AI']),
  _b('Probability and Statistics for Engineers', 'Richard A. Johnson (Miller & Freund)', 'Pearson', 'Probability & Statistics', 4, ['AI']),
  _b('Artificial Intelligence', 'Elaine Rich, Kevin Knight & Shivashankar B. Nair', 'McGraw Hill', 'Artificial Intelligence', 4, ['AI']),
  _b('Machine Learning', 'Tom M. Mitchell', 'McGraw Hill', 'Machine Learning', 5, ['AI']),
  _b('Introduction to Machine Learning with Python', 'Andreas C. Müller & Sarah Guido', "O'Reilly", 'Machine Learning', 5, ['AI']),
  _b('Hands-On Machine Learning with Scikit-Learn, Keras and TensorFlow', 'Aurélien Géron', "O'Reilly", 'Machine Learning & Deep Learning', 6, ['AI']),
  _b('Deep Learning', 'I. Goodfellow, Y. Bengio & A. Courville', 'MIT Press', 'Deep Learning', 7, ['AI']),
  _b('Speech and Language Processing', 'Daniel Jurafsky & James H. Martin', 'Pearson', 'Natural Language Processing', 7, ['AI']),
  _b('Digital Image Processing', 'R.C. Gonzalez & R.E. Woods', 'Pearson', 'Computer Vision', 7, ['AI']),

  /* ---------- Electronics & Communication (ECE) ---------- */
  _b('Electronic Devices and Circuit Theory', 'R.L. Boylestad & L. Nashelsky', 'Pearson', 'Electronic Devices', 3, ['ECE']),
  _b('Digital Design', 'M. Morris Mano & Michael D. Ciletti', 'Pearson', 'Digital Electronics', 3, ['ECE', 'EE']),
  _b('Network Analysis', 'M.E. Van Valkenburg', 'Pearson / PHI', 'Network Analysis', 3, ['ECE', 'EE']),
  _b('Signals and Systems', 'A.V. Oppenheim, A.S. Willsky & S.H. Nawab', 'Pearson', 'Signals & Systems', 4, ['ECE', 'EE']),
  _b('Microelectronic Circuits', 'A.S. Sedra & K.C. Smith', 'Oxford University Press', 'Analog Circuits', 4, ['ECE']),
  _b('Engineering Electromagnetics', 'William H. Hayt & John A. Buck', 'McGraw Hill', 'Electromagnetic Field Theory', 4, ['ECE', 'EE']),
  _b('Communication Systems', 'Simon Haykin', 'Wiley', 'Analog & Digital Communication', 5, ['ECE']),
  _b('Microprocessor Architecture, Programming and Applications with the 8085', 'Ramesh S. Gaonkar', 'Penram', 'Microprocessors', 5, ['ECE', 'EE']),
  _b('Digital Signal Processing', 'J.G. Proakis & D.G. Manolakis', 'Pearson', 'Digital Signal Processing', 5, ['ECE']),
  _b('Control Systems Engineering', 'I.J. Nagrath & M. Gopal', 'New Age International', 'Control Systems', 5, ['ECE', 'EE']),
  _b('The 8051 Microcontroller and Embedded Systems', 'Muhammad Ali Mazidi et al.', 'Pearson', 'Embedded Systems', 6, ['ECE']),
  _b('Antennas for All Applications', 'J.D. Kraus & R.J. Marhefka', 'McGraw Hill', 'Antenna & Wave Propagation', 6, ['ECE']),
  _b('CMOS Digital Integrated Circuits', 'S.-M. Kang & Y. Leblebici', 'McGraw Hill', 'VLSI Design', 7, ['ECE']),

  /* ---------- Electrical (EE) ---------- */
  _b('Electrical Machinery', 'P.S. Bimbhra', 'Khanna Publishers', 'Electrical Machines', 4, ['EE']),
  _b('Electric Machinery', 'A.E. Fitzgerald, C. Kingsley & S.D. Umans', 'McGraw Hill', 'Electrical Machines', 4, ['EE']),
  _b('A Course in Electrical and Electronic Measurements and Instrumentation', 'A.K. Sawhney', 'Dhanpat Rai', 'Measurements & Instrumentation', 4, ['EE']),
  _b('Modern Power System Analysis', 'D.P. Kothari & I.J. Nagrath', 'McGraw Hill', 'Power Systems', 5, ['EE']),
  _b('Power Electronics', 'M.H. Rashid', 'Pearson', 'Power Electronics', 5, ['EE']),
  _b('Principles of Power System', 'V.K. Mehta & Rohit Mehta', 'S. Chand', 'Power Systems', 6, ['EE']),
  _b('Power System Protection and Switchgear', 'Badri Ram & D.N. Vishwakarma', 'McGraw Hill', 'Switchgear & Protection', 6, ['EE']),

  /* ---------- Mechanical (ME) ---------- */
  _b('Vector Mechanics for Engineers: Statics and Dynamics', 'F.P. Beer & E.R. Johnston', 'McGraw Hill', 'Engineering Mechanics', 3, ['ME']),
  _b('Engineering Thermodynamics', 'P.K. Nag', 'McGraw Hill', 'Thermodynamics', 3, ['ME']),
  _b('Mechanics of Materials', 'F.P. Beer, E.R. Johnston et al.', 'McGraw Hill', 'Strength of Materials', 3, ['ME', 'CE']),
  _b('Materials Science and Engineering: An Introduction', 'William D. Callister Jr.', 'Wiley', 'Material Science', 3, ['ME']),
  _b('Elements of Workshop Technology, Vol. 1', 'S.K. Hajra Choudhury et al.', 'Media Promoters', 'Manufacturing Processes', 3, ['ME']),
  _b('Fluid Mechanics and Hydraulic Machines', 'R.K. Bansal', 'Laxmi Publications', 'Fluid Mechanics', 4, ['ME', 'CE']),
  _b('Theory of Machines', 'S.S. Rattan', 'McGraw Hill', 'Kinematics of Machines', 4, ['ME']),
  _b('Internal Combustion Engines', 'V. Ganesan', 'McGraw Hill', 'IC Engines', 5, ['ME']),
  _b('Fundamentals of Heat and Mass Transfer', 'F.P. Incropera et al.', 'Wiley', 'Heat Transfer', 5, ['ME']),
  _b('Design of Machine Elements', 'V.B. Bhandari', 'McGraw Hill', 'Machine Design', 5, ['ME']),
  _b('A Textbook of Refrigeration and Air Conditioning', 'R.S. Khurmi & J.K. Gupta', 'S. Chand', 'Refrigeration & Air Conditioning', 6, ['ME']),
  _b('Industrial Engineering and Management', 'O.P. Khanna', 'Dhanpat Rai', 'Industrial Engineering', 6, ['ME']),

  /* ---------- Civil (CE) ---------- */
  _b('Surveying, Vol. 1', 'B.C. Punmia, Ashok K. Jain & Arun K. Jain', 'Laxmi Publications', 'Surveying', 3, ['CE']),
  _b('Strength of Materials and Mechanics of Structures', 'B.C. Punmia & A.K. Jain', 'Laxmi Publications', 'Strength of Materials', 3, ['CE']),
  _b('Concrete Technology', 'M.S. Shetty', 'S. Chand', 'Concrete Technology', 4, ['CE']),
  _b('Basic Structural Analysis', 'C.S. Reddy', 'McGraw Hill', 'Structural Analysis', 4, ['CE']),
  _b('Soil Mechanics and Foundation Engineering', 'K.R. Arora', 'Standard Publishers', 'Geotechnical Engineering', 5, ['CE']),
  _b('Reinforced Concrete Design', 'S. Unnikrishna Pillai & Devdas Menon', 'McGraw Hill', 'RCC Design', 5, ['CE']),
  _b('Highway Engineering', 'S.K. Khanna, C.E.G. Justo & A. Veeraragavan', 'Nem Chand & Bros', 'Transportation Engineering', 5, ['CE']),
  _b('Water Supply Engineering (Environmental Engineering, Vol. 1)', 'S.K. Garg', 'Khanna Publishers', 'Environmental Engineering', 6, ['CE']),
  _b('Design of Steel Structures', 'S.K. Duggal', 'McGraw Hill', 'Steel Structures', 6, ['CE']),
  _b('Irrigation Engineering and Hydraulic Structures', 'S.K. Garg', 'Khanna Publishers', 'Irrigation Engineering', 6, ['CE'])
];
